import crypto from "node:crypto";

export type PublishResult =
  | { ok: true; mode: "live"; id: string; url: string }
  | { ok: true; mode: "simulated"; id: string; url: string; note: string }
  | { ok: false; error: string };

// ---------------------------------------------------------------------------
// Credential detection (all server-side env vars)
// ---------------------------------------------------------------------------
export function xCredentialMode(): "oauth1" | "oauth2" | "none" {
  if (process.env.X_API_KEY && process.env.X_API_SECRET && process.env.X_ACCESS_TOKEN && process.env.X_ACCESS_SECRET) return "oauth1";
  if (process.env.X_OAUTH2_ACCESS_TOKEN) return "oauth2";
  return "none";
}

export function threadsConfigured(): boolean {
  return Boolean(process.env.THREADS_ACCESS_TOKEN);
}

export function integrationStatus() {
  return {
    gemini: { configured: Boolean(process.env.GEMINI_API_KEY), model: process.env.GEMINI_MODEL || "gemini-2.5-flash" },
    x: { configured: xCredentialMode() !== "none", mode: xCredentialMode() },
    threads: { configured: threadsConfigured(), userId: process.env.THREADS_USER_ID || "me" },
    simulate: process.env.PUBLISH_SIMULATE === "1",
  };
}

// ---------------------------------------------------------------------------
// X.com — POST /2/tweets (OAuth 1.0a user context or OAuth 2.0 user token)
// ---------------------------------------------------------------------------
function pct(s: string) {
  return encodeURIComponent(s).replace(/[!'()*]/g, (c) => "%" + c.charCodeAt(0).toString(16).toUpperCase());
}

function oauth1Header(method: string, url: string): string {
  const consumerKey = process.env.X_API_KEY!;
  const consumerSecret = process.env.X_API_SECRET!;
  const token = process.env.X_ACCESS_TOKEN!;
  const tokenSecret = process.env.X_ACCESS_SECRET!;

  const params: Record<string, string> = {
    oauth_consumer_key: consumerKey,
    oauth_nonce: crypto.randomBytes(16).toString("hex"),
    oauth_signature_method: "HMAC-SHA1",
    oauth_timestamp: Math.floor(Date.now() / 1000).toString(),
    oauth_token: token,
    oauth_version: "1.0",
  };
  const paramString = Object.keys(params)
    .sort()
    .map((k) => `${pct(k)}=${pct(params[k])}`)
    .join("&");
  const base = `${method.toUpperCase()}&${pct(url)}&${pct(paramString)}`;
  const signingKey = `${pct(consumerSecret)}&${pct(tokenSecret)}`;
  const signature = crypto.createHmac("sha1", signingKey).update(base).digest("base64");
  params.oauth_signature = signature;

  return (
    "OAuth " +
    Object.keys(params)
      .sort()
      .map((k) => `${pct(k)}="${pct(params[k])}"`)
      .join(", ")
  );
}

export async function publishToX(text: string): Promise<PublishResult> {
  const mode = xCredentialMode();
  if (mode === "none" || process.env.PUBLISH_SIMULATE === "1") {
    const id = `sim_${Date.now()}`;
    return {
      ok: true,
      mode: "simulated",
      id,
      url: `https://x.com/i/status/${id}`,
      note:
        mode === "none"
          ? "X credentials not configured (set X_API_KEY, X_API_SECRET, X_ACCESS_TOKEN, X_ACCESS_SECRET). Post was simulated."
          : "PUBLISH_SIMULATE=1 — post was simulated.",
    };
  }

  const url = "https://api.x.com/2/tweets";
  const headers: Record<string, string> = { "content-type": "application/json" };
  headers.authorization = mode === "oauth1" ? oauth1Header("POST", url) : `Bearer ${process.env.X_OAUTH2_ACCESS_TOKEN}`;

  try {
    const res = await fetch(url, { method: "POST", headers, body: JSON.stringify({ text }) });
    const json = (await res.json().catch(() => ({}))) as { data?: { id: string }; detail?: string; title?: string; errors?: { message: string }[] };
    if (!res.ok || !json.data?.id) {
      const msg = json.detail || json.title || json.errors?.[0]?.message || `HTTP ${res.status}`;
      return { ok: false, error: `X API: ${msg}` };
    }
    const handle = process.env.X_HANDLE || "i";
    return { ok: true, mode: "live", id: json.data.id, url: `https://x.com/${handle}/status/${json.data.id}` };
  } catch (err) {
    return { ok: false, error: `X request failed: ${err instanceof Error ? err.message : String(err)}` };
  }
}

// ---------------------------------------------------------------------------
// Threads — two-step: create media container, then publish it
// ---------------------------------------------------------------------------
export async function publishToThreads(text: string): Promise<PublishResult> {
  if (!threadsConfigured() || process.env.PUBLISH_SIMULATE === "1") {
    const id = `sim_${Date.now()}`;
    return {
      ok: true,
      mode: "simulated",
      id,
      url: `https://www.threads.net/`,
      note: !threadsConfigured()
        ? "THREADS_ACCESS_TOKEN not configured. Post was simulated."
        : "PUBLISH_SIMULATE=1 — post was simulated.",
    };
  }

  const token = process.env.THREADS_ACCESS_TOKEN!;
  const userId = process.env.THREADS_USER_ID || "me";
  const base = `https://graph.threads.net/v1.0/${userId}`;

  try {
    // Step 1: container
    const createParams = new URLSearchParams({ media_type: "TEXT", text, access_token: token });
    const createRes = await fetch(`${base}/threads`, { method: "POST", body: createParams });
    const createJson = (await createRes.json().catch(() => ({}))) as { id?: string; error?: { message: string } };
    if (!createRes.ok || !createJson.id) {
      return { ok: false, error: `Threads container: ${createJson.error?.message || `HTTP ${createRes.status}`}` };
    }

    // Meta recommends waiting ~30s for media; text containers are usually ready immediately. Small pause for safety.
    await new Promise((r) => setTimeout(r, 1500));

    // Step 2: publish
    const pubParams = new URLSearchParams({ creation_id: createJson.id, access_token: token });
    const pubRes = await fetch(`${base}/threads_publish`, { method: "POST", body: pubParams });
    const pubJson = (await pubRes.json().catch(() => ({}))) as { id?: string; error?: { message: string } };
    if (!pubRes.ok || !pubJson.id) {
      return { ok: false, error: `Threads publish: ${pubJson.error?.message || `HTTP ${pubRes.status}`}` };
    }

    // Step 3: fetch permalink (best effort)
    let url = "https://www.threads.net/";
    try {
      const linkRes = await fetch(`https://graph.threads.net/v1.0/${pubJson.id}?fields=permalink&access_token=${encodeURIComponent(token)}`);
      const linkJson = (await linkRes.json()) as { permalink?: string };
      if (linkJson.permalink) url = linkJson.permalink;
    } catch {
      /* ignore */
    }
    return { ok: true, mode: "live", id: pubJson.id, url };
  } catch (err) {
    return { ok: false, error: `Threads request failed: ${err instanceof Error ? err.message : String(err)}` };
  }
}

/** Refreshes a long-lived Threads token (valid 60 days, refreshable after 24h). */
export async function refreshThreadsToken(): Promise<{ ok: boolean; token?: string; expiresIn?: number; error?: string }> {
  const token = process.env.THREADS_ACCESS_TOKEN;
  if (!token) return { ok: false, error: "THREADS_ACCESS_TOKEN not configured" };
  try {
    const res = await fetch(
      `https://graph.threads.net/refresh_access_token?grant_type=th_refresh_token&access_token=${encodeURIComponent(token)}`,
    );
    const json = (await res.json()) as { access_token?: string; expires_in?: number; error?: { message: string } };
    if (!res.ok || !json.access_token) return { ok: false, error: json.error?.message || `HTTP ${res.status}` };
    return { ok: true, token: json.access_token, expiresIn: json.expires_in };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) };
  }
}
