export const X_LINK_LENGTH = 23; // t.co wraps every URL to 23 chars
export const HARD_LIMITS: Record<string, number> = { x: 280, threads: 500 };

/** Character count as the platform will see it (X counts every URL as 23 chars). */
export function effectiveLength(text: string, platform: string): number {
  if (platform !== "x") return text.length;
  return text.replace(/https?:\/\/\S+/g, "x".repeat(X_LINK_LENGTH)).length;
}

export function timeAgo(d: string | Date | null | undefined): string {
  if (!d) return "";
  const t = typeof d === "string" ? new Date(d).getTime() : d.getTime();
  const diff = Math.max(0, Date.now() - t);
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const days = Math.floor(h / 24);
  if (days < 30) return `${days}d ago`;
  return new Date(t).toLocaleDateString();
}

export function hostname(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return url;
  }
}
