import Parser from "rss-parser";
import { db } from "@/db";
import { categories, feedItems, ingestRuns, sources, type Source } from "@/db/schema";
import { eq } from "drizzle-orm";
import { classifyItem } from "./classify";
import { ensureSeeded } from "./seed";

type RawItem = {
  externalId: string;
  title: string;
  link: string;
  snippet: string | null;
  author: string | null;
  publishedAt: Date | null;
};

// Several publishers (Reddit RSS, MarkTechPost, etc.) 403 non-browser user agents.
const UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36 AIDealRadar/1.0";
const FETCH_TIMEOUT_MS = 10_000;

// Per-host politeness: some hosts (Reddit) 429 concurrent requests from one IP.
// We serialise requests per host and add a gap for known strict hosts.
const HOST_GAP_MS: Record<string, number> = { "www.reddit.com": 8000, "reddit.com": 8000, "news.google.com": 400 };
/** Hosts where only N sources are polled per run (rotating by least-recently-fetched). */
const ROTATED_HOSTS: Record<string, number> = { "www.reddit.com": 2, "reddit.com": 2 };

function hostOf(url: string): string {
  try {
    return new URL(url).hostname;
  } catch {
    return "";
  }
}
const hostChains = new Map<string, Promise<void>>();

async function withHostThrottle<T>(url: string, fn: () => Promise<T>): Promise<T> {
  let host = "";
  try {
    host = new URL(url).hostname;
  } catch {
    return fn();
  }
  const gap = HOST_GAP_MS[host];
  if (!gap) return fn();

  const prev = hostChains.get(host) ?? Promise.resolve();
  let release!: () => void;
  const next = new Promise<void>((r) => (release = r));
  hostChains.set(host, prev.then(() => next));
  await prev;
  try {
    return await fn();
  } finally {
    setTimeout(release, gap);
  }
}

async function fetchText(url: string): Promise<string> {
  return withHostThrottle(url, () => fetchTextRaw(url));
}

async function fetchTextRaw(url: string): Promise<string> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      headers: { "user-agent": UA, accept: "application/rss+xml, application/atom+xml, application/xml, text/xml, application/json, */*" },
      signal: ctrl.signal,
      cache: "no-store",
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.text();
  } finally {
    clearTimeout(timer);
  }
}

function stripHtml(s: string | undefined | null): string | null {
  if (!s) return null;
  const txt = s
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, " ")
    .trim();
  return txt ? txt.slice(0, 600) : null;
}

const parser = new Parser({ timeout: FETCH_TIMEOUT_MS });

async function fetchRss(src: Source): Promise<RawItem[]> {
  const xml = await fetchText(src.url);
  const feed = await parser.parseString(xml);
  return (feed.items ?? [])
    .map((i) => {
      // guid can be a string or an xml2js object like { _: "id", isPermaLink: "false" }
      const g: unknown = i.guid;
      let guid: string | undefined;
      if (typeof g === "string") guid = g;
      else if (g && typeof g === "object") {
        const o = g as { _?: unknown; href?: unknown };
        guid = typeof o._ === "string" ? o._ : typeof o.href === "string" ? o.href : undefined;
      }
      return { ...i, guid };
    })
    .filter((i) => i.title && (i.link || i.guid))
    .map((i) => {
      const link = String(i.link || i.guid || "").trim();
      // Atom feeds return author as an object ({ name }) — normalise to string.
      const rawAuthor: unknown = i.creator ?? (i as { author?: unknown }).author ?? null;
      const author =
        typeof rawAuthor === "string"
          ? rawAuthor
          : rawAuthor && typeof rawAuthor === "object" && "name" in rawAuthor
            ? String((rawAuthor as { name: unknown }).name ?? "")
            : null;
      return {
        externalId: (i.guid || link).trim(),
        title: i.title!.trim(),
        link,
        snippet: stripHtml(i.contentSnippet || i.content || i.summary || null),
        author: author || null,
        publishedAt: i.isoDate ? new Date(i.isoDate) : i.pubDate ? new Date(i.pubDate) : null,
      };
    });
}

type HnHit = {
  objectID: string;
  title: string | null;
  url: string | null;
  author: string;
  created_at: string;
  story_text?: string | null;
  points?: number;
};

async function fetchHackerNews(src: Source): Promise<RawItem[]> {
  const query = src.url.replace(/^hn:/, "");
  const api = `https://hn.algolia.com/api/v1/search_by_date?query=${encodeURIComponent(query)}&tags=story&hitsPerPage=${src.maxItemsPerRun}`;
  const json = JSON.parse(await fetchText(api)) as { hits: HnHit[] };
  return json.hits
    .filter((h) => h.title)
    .map((h) => ({
      externalId: `hn:${h.objectID}`,
      title: h.title!,
      link: h.url || `https://news.ycombinator.com/item?id=${h.objectID}`,
      snippet: stripHtml(h.story_text) ?? `${h.points ?? 0} points on Hacker News`,
      author: h.author,
      publishedAt: new Date(h.created_at),
    }));
}

type RedditChild = {
  data: {
    id: string;
    title: string;
    permalink: string;
    url: string;
    selftext?: string;
    author: string;
    created_utc: number;
    subreddit: string;
  };
};

async function fetchReddit(src: Source): Promise<RawItem[]> {
  const sep = src.url.includes("?") ? "&" : "?";
  const json = JSON.parse(await fetchText(`${src.url}${sep}limit=${src.maxItemsPerRun}&raw_json=1`)) as {
    data: { children: RedditChild[] };
  };
  return json.data.children.map(({ data: d }) => ({
    externalId: `reddit:${d.id}`,
    title: d.title,
    link: d.url && !d.url.includes("reddit.com") ? d.url : `https://www.reddit.com${d.permalink}`,
    snippet: stripHtml(d.selftext) ?? `Posted in r/${d.subreddit}`,
    author: d.author,
    publishedAt: new Date(d.created_utc * 1000),
  }));
}

async function fetchSource(src: Source): Promise<RawItem[]> {
  switch (src.kind) {
    case "hn":
      return fetchHackerNews(src);
    case "reddit":
      return fetchReddit(src);
    default:
      return fetchRss(src);
  }
}

/** Re-runs the keyword classifier over every stored item (use after editing category keywords). */
export async function reclassifyAll(): Promise<{ updated: number }> {
  await ensureSeeded();
  const cats = await db.select().from(categories);
  const rows = await db
    .select({ id: feedItems.id, title: feedItems.title, snippet: feedItems.snippet, sourceType: feedItems.sourceType })
    .from(feedItems);
  let updated = 0;
  for (const r of rows) {
    const c = classifyItem(r.title, r.snippet, cats, r.sourceType);
    await db
      .update(feedItems)
      .set({ categoryId: c.categoryId, categorySlug: c.categorySlug, relevanceScore: c.score, isDeal: c.isDeal, matchedKeywords: c.matched })
      .where(eq(feedItems.id, r.id));
    updated++;
  }
  return { updated };
}

export type IngestSummary = {
  runId: number;
  sourcesChecked: number;
  itemsFetched: number;
  itemsInserted: number;
  errors: { source: string; error: string }[];
  durationMs: number;
};

/** Runs every enabled source with bounded concurrency, classifies and stores new items. */
export async function runIngest(opts?: { sourceIds?: number[]; concurrency?: number }): Promise<IngestSummary> {
  await ensureSeeded();
  const started = Date.now();
  const [run] = await db.insert(ingestRuns).values({}).returning();

  const cats = await db.select().from(categories);
  let srcs = await db.select().from(sources).where(eq(sources.enabled, true));
  if (opts?.sourceIds?.length) srcs = srcs.filter((s) => opts.sourceIds!.includes(s.id));

  // Round-robin rotation for hosts that hard-limit unauthenticated traffic (Reddit
  // allows roughly one RSS hit per IP per minute). Only the N least-recently-fetched
  // sources on such hosts run each cycle; the rest wait for the next run.
  const explicit = Boolean(opts?.sourceIds?.length);
  if (!explicit) {
    const byHost = new Map<string, Source[]>();
    for (const s of srcs) {
      const host = hostOf(s.url);
      if (host && ROTATED_HOSTS[host]) byHost.set(host, [...(byHost.get(host) ?? []), s]);
    }
    const skip = new Set<number>();
    for (const [host, list] of byHost) {
      const perRun = ROTATED_HOSTS[host];
      list.sort((a, b) => (a.lastFetchedAt?.getTime() ?? 0) - (b.lastFetchedAt?.getTime() ?? 0));
      list.slice(perRun).forEach((s) => skip.add(s.id));
    }
    srcs = srcs.filter((s) => !skip.has(s.id));
  }

  const errors: { source: string; error: string }[] = [];
  let fetched = 0;
  let inserted = 0;

  const concurrency = opts?.concurrency ?? 6;
  const queue = [...srcs];

  const worker = async () => {
    while (queue.length) {
      const src = queue.shift()!;
      try {
        const raw = (await fetchSource(src)).slice(0, src.maxItemsPerRun);
        fetched += raw.length;

        if (raw.length) {
          const rows = raw.map((r) => {
            const c = classifyItem(r.title, r.snippet, cats, src.sourceType);
            return {
              sourceId: src.id,
              sourceName: src.name,
              sourceType: src.sourceType,
              externalId: r.externalId.slice(0, 1000),
              title: r.title.slice(0, 500),
              link: r.link,
              snippet: r.snippet,
              author: r.author?.slice(0, 160) ?? null,
              publishedAt: r.publishedAt && !isNaN(r.publishedAt.getTime()) ? r.publishedAt : null,
              categoryId: c.categoryId,
              categorySlug: c.categorySlug,
              relevanceScore: c.score,
              isDeal: c.isDeal,
              matchedKeywords: c.matched,
            };
          });
          const res = await db.insert(feedItems).values(rows).onConflictDoNothing().returning({ id: feedItems.id });
          inserted += res.length;
        }

        await db
          .update(sources)
          .set({ lastFetchedAt: new Date(), lastStatus: "ok", lastError: null })
          .where(eq(sources.id, src.id));
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        errors.push({ source: src.name, error: msg });
        await db
          .update(sources)
          .set({ lastFetchedAt: new Date(), lastStatus: "error", lastError: msg.slice(0, 500) })
          .where(eq(sources.id, src.id));
      }
    }
  };

  await Promise.all(Array.from({ length: Math.min(concurrency, srcs.length || 1) }, worker));

  await db
    .update(ingestRuns)
    .set({ finishedAt: new Date(), sourcesChecked: srcs.length, itemsFetched: fetched, itemsInserted: inserted, errors })
    .where(eq(ingestRuns.id, run.id));

  return { runId: run.id, sourcesChecked: srcs.length, itemsFetched: fetched, itemsInserted: inserted, errors, durationMs: Date.now() - started };
}
