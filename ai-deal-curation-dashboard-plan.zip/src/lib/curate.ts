import { GoogleGenAI } from "@google/genai";
import type { FeedItem, Template } from "@/db/schema";

import { X_LINK_LENGTH, effectiveLength } from "./text";
export { X_LINK_LENGTH, effectiveLength };

function truncate(s: string, n: number) {
  return s.length <= n ? s : s.slice(0, Math.max(0, n - 1)).trimEnd() + "…";
}

/** Deterministic fallback used when no Gemini key is configured or the call fails. */
export function fallbackDraft(item: FeedItem, tpl: Template): string {
  const link = tpl.includeLink ? item.link : "";
  const tags = tpl.hashtags.trim();
  const budget = tpl.maxChars - (link ? X_LINK_LENGTH + 2 : 0) - (tags ? tags.length + 2 : 0);

  const catLabel: Record<string, string> = {
    "subscription-deals": "Deal alert",
    "api-credits": "Free credits / price cut",
    "free-tiers": "Free access",
    "model-releases": "New model",
    "tool-launches": "New AI tool",
    "influencer-promos": "Creator promo",
    other: "AI update",
  };
  const emoji: Record<string, string> = {
    "subscription-deals": "🔥",
    "api-credits": "💳",
    "free-tiers": "🆓",
    "model-releases": "🚀",
    "tool-launches": "🛠️",
    "influencer-promos": "🎟️",
    other: "🤖",
  };

  const e = emoji[item.categorySlug] ?? "🤖";
  const label = catLabel[item.categorySlug] ?? "AI update";

  if (tpl.platform === "x") {
    const hook = `${e} ${label}: ${item.title}`;
    const detail = item.snippet ? `\n\n${item.snippet}` : "";
    let body = truncate(hook + detail, budget);
    if (tags) body += `\n\n${tags}`;
    if (link) body += `\n${link}`;
    return body;
  }

  const open = `Okay this one's worth a look ${e}\n\n${item.title}.`;
  const detail = item.snippet ? ` ${item.snippet}` : "";
  const close = `\n\nAnyone here already using it? Curious what you think.`;
  let body = truncate(open + detail, budget - close.length) + close;
  if (tags) body += `\n\n${tags}`;
  if (link) body += `\n${link}`;
  return body;
}

const PLATFORM_FACTS: Record<string, string> = {
  x: "Platform: X.com. Every URL is counted as exactly 23 characters no matter its real length. Hard limit 280; target the given maxChars. Line breaks are allowed and encouraged.",
  threads: "Platform: Threads (Meta). Hard limit 500 characters. Conversational tone, no walls of text, line breaks allowed.",
};

export async function generateDraft(
  item: FeedItem,
  tpl: Template,
): Promise<{ content: string; generator: "gemini" | "fallback"; warning?: string }> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return { content: fallbackDraft(item, tpl), generator: "fallback", warning: "GEMINI_API_KEY not set — used template fallback." };
  }

  const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";
  const ai = new GoogleGenAI({ apiKey });

  const system =
    "You are a sharp social media manager specialising in AI tools, subscriptions and developer deals. " +
    "You write posts that are accurate to the source (never invent prices, dates or codes that are not in the source), concise and human. " +
    "Output ONLY valid JSON matching: {\"post\": string}. No markdown fences.";

  const user = [
    PLATFORM_FACTS[tpl.platform] ?? "",
    `Template: ${tpl.name}`,
    `Tone: ${tpl.tone}`,
    `Instructions: ${tpl.instructions}`,
    `Max characters (including link counted as 23 chars on X): ${tpl.maxChars}`,
    tpl.hashtags ? `Preferred hashtags (use at most these): ${tpl.hashtags}` : "Hashtags: none required.",
    tpl.includeLink ? `Include this exact link on the last line: ${item.link}` : "Do not include a link.",
    "",
    "SOURCE ITEM",
    `Category: ${item.categorySlug}`,
    `Source: ${item.sourceName} (${item.sourceType})`,
    `Title: ${item.title}`,
    `Snippet: ${item.snippet ?? "(none)"}`,
    item.matchedKeywords?.length ? `Signals: ${item.matchedKeywords.join(", ")}` : "",
  ]
    .filter(Boolean)
    .join("\n");

  try {
    const res = await ai.models.generateContent({
      model,
      contents: user,
      config: {
        systemInstruction: system,
        responseMimeType: "application/json",
        temperature: 0.7,
        maxOutputTokens: 600,
      },
    });
    const text = res.text ?? "";
    let post = "";
    try {
      const parsed = JSON.parse(text) as { post?: string };
      post = (parsed.post ?? "").trim();
    } catch {
      post = text.replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
    }
    if (!post) throw new Error("Empty response from Gemini");

    // Safety clamp: if the model overshoots, trim body but keep the link.
    if (effectiveLength(post, tpl.platform) > tpl.maxChars) {
      const link = tpl.includeLink ? item.link : "";
      const withoutLink = post.replace(item.link, "").trimEnd();
      const budget = tpl.maxChars - (link ? X_LINK_LENGTH + 1 : 0);
      post = truncate(withoutLink, budget) + (link ? `\n${link}` : "");
    }
    return { content: post, generator: "gemini" };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return { content: fallbackDraft(item, tpl), generator: "fallback", warning: `Gemini failed (${msg.slice(0, 160)}) — used template fallback.` };
  }
}
