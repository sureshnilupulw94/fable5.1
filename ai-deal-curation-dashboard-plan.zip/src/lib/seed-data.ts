export const CATEGORY_SEED = [
  {
    slug: "subscription-deals",
    name: "Subscription Deals",
    description: "Discounts and promos on AI subscriptions (ChatGPT Plus, Claude Pro, Gemini Advanced, Copilot, Perplexity...)",
    color: "emerald",
    sortOrder: 1,
    keywords: [
      "discount", "% off", "percent off", "coupon", "promo code", "promo", "deal", "sale", "black friday",
      "cyber monday", "lifetime deal", "ltd", "appsumo", "price drop", "cheaper", "half price", "save $",
      "subscription", "plus plan", "pro plan", "annual plan", "student discount", "offer ends",
    ],
  },
  {
    slug: "api-credits",
    name: "API Credits & Cloud",
    description: "Free API credits, cloud credits, startup programs and token-price cuts.",
    color: "sky",
    sortOrder: 2,
    keywords: [
      "credits", "api credits", "cloud credits", "free credits", "$ in credits", "startup program",
      "price cut", "price reduction", "pricing", "per million tokens", "batch api", "token price",
      "cheaper tokens", "gpu credits", "compute credits", "azure credits", "aws activate", "google cloud credits",
    ],
  },
  {
    slug: "free-tiers",
    name: "Free Tiers & Trials",
    description: "Free plans, free trials, giveaways and 'free for a limited time' announcements.",
    color: "violet",
    sortOrder: 3,
    keywords: [
      "free tier", "free trial", "free for", "now free", "free access", "free plan", "giveaway",
      "limited time", "free month", "trial", "no credit card", "free forever", "open access", "free to use",
    ],
  },
  {
    slug: "model-releases",
    name: "Model Releases",
    description: "New models, major versions, benchmark leaps.",
    color: "amber",
    sortOrder: 4,
    keywords: [
      "introducing", "announcing", "new model", "release", "released", "launches", "launch", "now available",
      "gpt-", "claude", "gemini", "llama", "mistral", "grok", "deepseek", "qwen", "sonnet", "opus", "o3", "o4",
      "benchmark", "state of the art", "sota", "open weights", "open-source model",
    ],
  },
  {
    slug: "tool-launches",
    name: "Tool Launches",
    description: "New AI tools, features, agents and product updates.",
    color: "rose",
    sortOrder: 5,
    keywords: [
      "product hunt", "launch", "launched", "new feature", "feature", "agent", "copilot", "assistant",
      "plugin", "extension", "app", "tool", "beta", "early access", "waitlist", "update", "changelog",
    ],
  },
  {
    slug: "influencer-promos",
    name: "Influencer Promos",
    description: "Creator and community-shared codes, referral links and deal round-ups.",
    color: "fuchsia",
    sortOrder: 6,
    keywords: [
      "referral", "affiliate", "use my code", "use code", "code:", "invite", "sponsored", "partner link",
      "exclusive", "my link", "link in bio", "roundup", "round-up", "best deals", "top deals",
    ],
  },
  {
    slug: "other",
    name: "Other AI News",
    description: "Everything else that mentions AI but does not match a deal category.",
    color: "slate",
    sortOrder: 99,
    keywords: [],
  },
] as const;

export type SourceSeed = {
  name: string;
  url: string;
  kind: "rss" | "hn" | "reddit";
  sourceType: "official" | "influencer" | "community" | "deals";
  maxItemsPerRun?: number;
};

export const SOURCE_SEED: SourceSeed[] = [
  // ---- Official AI labs & vendors ----
  { name: "OpenAI News", url: "https://openai.com/news/rss.xml", kind: "rss", sourceType: "official" },
  { name: "Anthropic (via Google News)", url: "https://news.google.com/rss/search?q=site:anthropic.com&hl=en-US&gl=US&ceid=US:en", kind: "rss", sourceType: "official" },
  { name: "Google DeepMind Blog", url: "https://deepmind.google/blog/rss.xml", kind: "rss", sourceType: "official" },
  { name: "Google AI Blog", url: "https://blog.google/technology/ai/rss/", kind: "rss", sourceType: "official" },
  { name: "Hugging Face Blog", url: "https://huggingface.co/blog/feed.xml", kind: "rss", sourceType: "official" },
  { name: "Microsoft Official Blog", url: "https://blogs.microsoft.com/feed/", kind: "rss", sourceType: "official" },
  { name: "Azure Blog", url: "https://azure.microsoft.com/en-us/blog/feed/", kind: "rss", sourceType: "official" },
  { name: "GitHub Changelog", url: "https://github.blog/changelog/feed/", kind: "rss", sourceType: "official" },
  { name: "Vercel Blog", url: "https://vercel.com/atom", kind: "rss", sourceType: "official" },
  { name: "Cloudflare Blog", url: "https://blog.cloudflare.com/rss/", kind: "rss", sourceType: "official" },
  { name: "AWS Machine Learning Blog", url: "https://aws.amazon.com/blogs/machine-learning/feed/", kind: "rss", sourceType: "official" },
  { name: "Mistral AI (via Google News)", url: "https://news.google.com/rss/search?q=%22Mistral+AI%22&hl=en-US&gl=US&ceid=US:en", kind: "rss", sourceType: "official" },
  { name: "xAI / Grok (via Google News)", url: "https://news.google.com/rss/search?q=xAI+Grok&hl=en-US&gl=US&ceid=US:en", kind: "rss", sourceType: "official" },
  { name: "Replicate Blog", url: "https://replicate.com/blog/rss", kind: "rss", sourceType: "official" },

  // ---- Tech press ----
  { name: "TechCrunch AI", url: "https://techcrunch.com/category/artificial-intelligence/feed/", kind: "rss", sourceType: "official" },
  { name: "The Verge AI", url: "https://www.theverge.com/rss/ai-artificial-intelligence/index.xml", kind: "rss", sourceType: "official" },
  { name: "VentureBeat", url: "https://feeds.feedburner.com/venturebeat/SZYF", kind: "rss", sourceType: "official" },
  { name: "MIT Technology Review AI", url: "https://www.technologyreview.com/topic/artificial-intelligence/feed", kind: "rss", sourceType: "official" },
  { name: "Ars Technica AI", url: "https://arstechnica.com/ai/feed/", kind: "rss", sourceType: "official" },
  { name: "The Decoder", url: "https://the-decoder.com/feed/", kind: "rss", sourceType: "official" },
  { name: "MarkTechPost", url: "https://www.marktechpost.com/feed/", kind: "rss", sourceType: "official" },
  { name: "9to5Google AI", url: "https://9to5google.com/guides/ai/feed/", kind: "rss", sourceType: "official" },

  // ---- Communities / aggregators ----
  { name: "Hacker News: AI deals & pricing", url: "hn:ai discount OR credits OR pricing OR free tier", kind: "hn", sourceType: "community", maxItemsPerRun: 25 },
  { name: "Hacker News: LLM launches", url: "hn:gpt OR claude OR gemini OR llama OR openai OR anthropic", kind: "hn", sourceType: "community", maxItemsPerRun: 25 },
  { name: "Product Hunt", url: "https://www.producthunt.com/feed", kind: "rss", sourceType: "community" },
  { name: "Reddit r/artificial", url: "https://www.reddit.com/r/artificial/new.rss", kind: "rss", sourceType: "community" },
  { name: "Reddit r/OpenAI", url: "https://www.reddit.com/r/OpenAI/new.rss", kind: "rss", sourceType: "community" },
  { name: "Reddit r/ClaudeAI", url: "https://www.reddit.com/r/ClaudeAI/new.rss", kind: "rss", sourceType: "community" },
  { name: "Reddit r/LocalLLaMA", url: "https://www.reddit.com/r/LocalLLaMA/new.rss", kind: "rss", sourceType: "community" },
  { name: "Reddit r/ChatGPT", url: "https://www.reddit.com/r/ChatGPT/new.rss", kind: "rss", sourceType: "community" },

  // ---- Deal trackers ----
  { name: "Reddit r/deals (AI)", url: "https://www.reddit.com/r/deals/search.rss?q=AI+OR+ChatGPT+OR+Claude+OR+subscription&sort=new&restrict_sr=1", kind: "rss", sourceType: "deals" },
  { name: "Reddit r/SaaS (AI deals)", url: "https://www.reddit.com/r/SaaS/search.rss?q=AI+discount+OR+lifetime+deal&sort=new&restrict_sr=1", kind: "rss", sourceType: "deals" },
  { name: "DealNews Software", url: "https://www.dealnews.com/c39/Computers/Software/?rss=1", kind: "rss", sourceType: "deals" },
  { name: "Slickdeals (AI search)", url: "https://slickdeals.net/newsearch.php?mode=frontpage&searcharea=deals&searchin=first&rss=1&q=ai", kind: "rss", sourceType: "deals" },
  { name: "Google News: AI subscription discount", url: "https://news.google.com/rss/search?q=%22AI%22+subscription+discount+OR+promo+OR+deal&hl=en-US&gl=US&ceid=US:en", kind: "rss", sourceType: "deals" },
  { name: "Google News: AI free credits", url: "https://news.google.com/rss/search?q=AI+%22free+credits%22+OR+%22free+tier%22+OR+%22free+trial%22&hl=en-US&gl=US&ceid=US:en", kind: "rss", sourceType: "deals" },
  { name: "Google News: ChatGPT Claude Gemini offer", url: "https://news.google.com/rss/search?q=(ChatGPT+OR+Claude+OR+Gemini+OR+Copilot+OR+Perplexity)+(offer+OR+free+OR+discount)&hl=en-US&gl=US&ceid=US:en", kind: "rss", sourceType: "deals" },
  { name: "Google News: AppSumo AI lifetime deals", url: "https://news.google.com/rss/search?q=AppSumo+AI+lifetime+deal&hl=en-US&gl=US&ceid=US:en", kind: "rss", sourceType: "deals" },

  // ---- Influencer / creator channels (newsletters, blogs, YouTube) ----
  { name: "Ben's Bites (newsletter)", url: "https://www.bensbites.com/feed", kind: "rss", sourceType: "influencer" },
  { name: "The Rundown AI", url: "https://www.therundown.ai/feed", kind: "rss", sourceType: "influencer" },
  { name: "TLDR AI", url: "https://tldr.tech/api/rss/ai", kind: "rss", sourceType: "influencer" },
  { name: "Simon Willison", url: "https://simonwillison.net/atom/everything/", kind: "rss", sourceType: "influencer" },
  { name: "Latent Space", url: "https://www.latent.space/feed", kind: "rss", sourceType: "influencer" },
  { name: "Import AI (Jack Clark)", url: "https://importai.substack.com/feed", kind: "rss", sourceType: "influencer" },
  { name: "One Useful Thing (Ethan Mollick)", url: "https://www.oneusefulthing.org/feed", kind: "rss", sourceType: "influencer" },
  { name: "YouTube: Matt Wolfe", url: "https://www.youtube.com/feeds/videos.xml?channel_id=UChpleBmo18P08aKCIgti38g", kind: "rss", sourceType: "influencer" },
  { name: "YouTube: AI Explained", url: "https://www.youtube.com/feeds/videos.xml?channel_id=UCNJ1Ymd5yFuUPtn21xtRbbw", kind: "rss", sourceType: "influencer" },
  { name: "YouTube: Fireship", url: "https://www.youtube.com/feeds/videos.xml?channel_id=UCsBjURrPoezykLs9EqgamOA", kind: "rss", sourceType: "influencer" },
];

export const TEMPLATE_SEED = [
  {
    platform: "x",
    name: "X — Deal Alert",
    tone: "punchy",
    maxChars: 270,
    includeLink: true,
    hashtags: "#AI #AIDeals",
    sortOrder: 1,
    instructions:
      "Write a hook-driven post for X.com. Line 1 is a scroll-stopping hook (emoji allowed, no clickbait). " +
      "Then 1-2 short lines with the concrete value (what, how much, for whom, until when if known). " +
      "Use line breaks for scannability. End with the link on its own line. Stay under the character limit including the link (count the link as 23 chars). " +
      "Max 2 hashtags. No markdown, no quotes around the post.",
  },
  {
    platform: "threads",
    name: "Threads — Community Take",
    tone: "conversational",
    maxChars: 480,
    includeLink: true,
    hashtags: "",
    sortOrder: 2,
    instructions:
      "Write a warm, conversational Threads post like you're telling a friend about a find. " +
      "Open with a one-line reaction, explain the deal/news in 2-3 plain sentences, mention who it's useful for, " +
      "and close with a light question to invite replies. Put the link on the last line. No hashtags unless one is truly relevant. No markdown.",
  },
] as const;
