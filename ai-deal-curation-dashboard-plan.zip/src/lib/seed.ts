import { db } from "@/db";
import { categories, sources, templates } from "@/db/schema";
import { CATEGORY_SEED, SOURCE_SEED, TEMPLATE_SEED } from "./seed-data";
import { sql } from "drizzle-orm";

let seededOnce = false;

/** Idempotently ensures categories, sources and templates exist. Safe to call on every request. */
export async function ensureSeeded() {
  if (seededOnce) return;

  const [catCount] = await db.select({ c: sql<number>`count(*)::int` }).from(categories);
  if (!catCount || catCount.c === 0) {
    await db
      .insert(categories)
      .values(
        CATEGORY_SEED.map((c) => ({
          slug: c.slug,
          name: c.name,
          description: c.description,
          keywords: [...c.keywords],
          color: c.color,
          sortOrder: c.sortOrder,
        })),
      )
      .onConflictDoNothing();
  }

  const [srcCount] = await db.select({ c: sql<number>`count(*)::int` }).from(sources);
  if (!srcCount || srcCount.c === 0) {
    await db
      .insert(sources)
      .values(
        SOURCE_SEED.map((s) => ({
          name: s.name,
          url: s.url,
          kind: s.kind,
          sourceType: s.sourceType,
          maxItemsPerRun: s.maxItemsPerRun ?? 15,
        })),
      )
      .onConflictDoNothing();
  }

  const [tplCount] = await db.select({ c: sql<number>`count(*)::int` }).from(templates);
  if (!tplCount || tplCount.c === 0) {
    await db.insert(templates).values(
      TEMPLATE_SEED.map((t) => ({
        platform: t.platform,
        name: t.name,
        tone: t.tone,
        maxChars: t.maxChars,
        includeLink: t.includeLink,
        hashtags: t.hashtags,
        sortOrder: t.sortOrder,
        instructions: t.instructions,
      })),
    );
  }

  seededOnce = true;
}
