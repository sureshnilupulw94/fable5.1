import type { Category } from "@/db/schema";

const AI_SIGNALS = [
  "ai", "a.i.", "llm", "llms", "gpt", "chatgpt", "openai", "claude", "anthropic", "gemini", "copilot", "midjourney",
  "stable diffusion", "perplexity", "cursor", "windsurf", "grok", "xai", "llama", "mistral", "deepseek", "qwen",
  "machine learning", "language model", "foundation model", "agent", "agents", "agentic", "hugging face", "huggingface",
  "api", "tokens", "inference", "neural", "generative", "gen ai", "genai", "codex", "sora", "veo", "notebooklm",
  "lovable", "replit", "bolt.new", "v0", "runway", "elevenlabs", "suno", "openrouter", "groq", "together ai", "fireworks ai",
  "vertex ai", "bedrock", "azure openai", "github copilot", "claude code", "gemini cli",
];

const DEAL_SIGNALS = [
  "discount", "% off", "percent off", "coupon", "promo", "promo code", "deal", "deals", "sale", "credits", "free tier",
  "free trial", "now free", "free for", "free plan", "price cut", "price drop", "lifetime", "giveaway", "limited time",
  "offer", "referral", "save $", "cheaper", "pricing", "free month", "student", "students", "waived", "for free",
  "free access", "no credit card", "half price", "black friday", "cyber monday", "appsumo",
];

// Business-y phrases that use "deal" but are not consumer offers.
const NEGATIVE_SIGNALS = ["billion deal", "acquisition deal", "funding", "raises $", "ipo", "valuation", "lawsuit", "merger"];

export type Classification = {
  categorySlug: string;
  categoryId: number | null;
  score: number;
  isDeal: boolean;
  matched: string[];
};

const regexCache = new Map<string, RegExp>();

/** Word-boundary aware matcher so "ai" doesn't match "again" or "email". */
function matcher(needle: string): RegExp {
  let re = regexCache.get(needle);
  if (!re) {
    const escaped = needle.toLowerCase().replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const startsAlnum = /^[a-z0-9]/i.test(needle);
    const endsAlnum = /[a-z0-9]$/i.test(needle);
    re = new RegExp(`${startsAlnum ? "(?<![a-z0-9])" : ""}${escaped}${endsAlnum ? "(?![a-z0-9])" : ""}`, "i");
    regexCache.set(needle, re);
  }
  return re;
}

function countMatches(text: string, needles: readonly string[]): string[] {
  const found: string[] = [];
  for (const n of needles) {
    if (n && matcher(n).test(text)) found.push(n);
  }
  return found;
}

const DEAL_CATEGORIES = new Set(["subscription-deals", "api-credits", "free-tiers", "influencer-promos"]);

/**
 * Fast, zero-cost keyword classifier. Scores each predetermined category by
 * keyword hits (title hits weigh double) and picks the best. Deal categories
 * require genuine AI relevance so generic retail deals fall through to "other".
 */
export function classifyItem(
  title: string,
  snippet: string | null | undefined,
  cats: Category[],
  sourceType: string,
): Classification {
  const t = title.toLowerCase();
  const body = `${title} ${snippet ?? ""}`.toLowerCase();

  const aiHits = countMatches(body, AI_SIGNALS);
  const aiTitleHits = countMatches(t, AI_SIGNALS);
  const dealHits = countMatches(body, DEAL_SIGNALS);
  const negativeHits = countMatches(body, NEGATIVE_SIGNALS);
  const aiRelevant = aiHits.length > 0;

  let best: { cat: Category; score: number; matched: string[] } | null = null;

  for (const cat of cats) {
    if (cat.slug === "other") continue;
    const kws = cat.keywords ?? [];
    const titleHits = countMatches(t, kws);
    const bodyHits = countMatches(body, kws);
    const matched = Array.from(new Set([...titleHits, ...bodyHits]));
    let score = titleHits.length * 2 + bodyHits.length;

    if (DEAL_CATEGORIES.has(cat.slug)) {
      if (!aiRelevant) score = 0; // a laptop sale is not an AI deal
      if (negativeHits.length) score -= negativeHits.length * 2; // "$45B deal with Anthropic" is news, not a promo
    }
    if (cat.slug === "influencer-promos" && sourceType === "influencer" && dealHits.length > 0) score += 2;
    if (cat.slug === "subscription-deals" && sourceType === "deals" && aiRelevant) score += 1;
    if ((cat.slug === "model-releases" || cat.slug === "tool-launches") && !aiRelevant) score -= 1;

    if (score > 0 && (!best || score > best.score)) best = { cat, score, matched };
  }

  const isDeal = aiRelevant && dealHits.length > 0 && negativeHits.length === 0;
  const relevance = Math.min(
    1,
    aiHits.length * 0.1 + aiTitleHits.length * 0.1 + (isDeal ? dealHits.length * 0.2 : 0) + (best?.score ?? 0) * 0.06,
  );

  if (!best || best.score < 1) {
    const other = cats.find((c) => c.slug === "other");
    return { categorySlug: "other", categoryId: other?.id ?? null, score: relevance, isDeal, matched: isDeal ? dealHits : [] };
  }

  return {
    categorySlug: best.cat.slug,
    categoryId: best.cat.id,
    score: relevance,
    isDeal,
    matched: Array.from(new Set([...best.matched, ...(isDeal ? dealHits : [])])).slice(0, 8),
  };
}
