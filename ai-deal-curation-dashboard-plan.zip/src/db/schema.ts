import {
  pgTable,
  serial,
  text,
  varchar,
  boolean,
  integer,
  timestamp,
  jsonb,
  real,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 64 }).notNull().unique(),
  name: varchar("name", { length: 128 }).notNull(),
  description: text("description"),
  keywords: jsonb("keywords").$type<string[]>().notNull().default([]),
  color: varchar("color", { length: 32 }).notNull().default("slate"),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const sources = pgTable("sources", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  url: text("url").notNull().unique(),
  // rss | hn | reddit | json
  kind: varchar("kind", { length: 24 }).notNull().default("rss"),
  // official | influencer | community | deals
  sourceType: varchar("source_type", { length: 24 }).notNull().default("official"),
  enabled: boolean("enabled").notNull().default(true),
  maxItemsPerRun: integer("max_items_per_run").notNull().default(15),
  lastFetchedAt: timestamp("last_fetched_at", { withTimezone: true }),
  lastStatus: varchar("last_status", { length: 32 }),
  lastError: text("last_error"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const feedItems = pgTable(
  "feed_items",
  {
    id: serial("id").primaryKey(),
    sourceId: integer("source_id").references(() => sources.id, { onDelete: "set null" }),
    sourceName: varchar("source_name", { length: 160 }).notNull(),
    sourceType: varchar("source_type", { length: 24 }).notNull().default("official"),
    externalId: text("external_id").notNull(),
    title: text("title").notNull(),
    link: text("link").notNull(),
    snippet: text("snippet"),
    author: varchar("author", { length: 160 }),
    publishedAt: timestamp("published_at", { withTimezone: true }),
    categoryId: integer("category_id").references(() => categories.id, { onDelete: "set null" }),
    categorySlug: varchar("category_slug", { length: 64 }).notNull().default("other"),
    relevanceScore: real("relevance_score").notNull().default(0),
    isDeal: boolean("is_deal").notNull().default(false),
    matchedKeywords: jsonb("matched_keywords").$type<string[]>().notNull().default([]),
    // new | used | archived
    status: varchar("status", { length: 16 }).notNull().default("new"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("feed_items_external_id_idx").on(t.externalId),
    index("feed_items_category_idx").on(t.categorySlug),
    index("feed_items_created_idx").on(t.createdAt),
  ],
);

export const templates = pgTable("templates", {
  id: serial("id").primaryKey(),
  // x | threads
  platform: varchar("platform", { length: 16 }).notNull(),
  name: varchar("name", { length: 128 }).notNull(),
  instructions: text("instructions").notNull(),
  maxChars: integer("max_chars").notNull().default(280),
  hashtags: varchar("hashtags", { length: 256 }).notNull().default(""),
  includeLink: boolean("include_link").notNull().default(true),
  tone: varchar("tone", { length: 64 }).notNull().default("punchy"),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const drafts = pgTable("drafts", {
  id: serial("id").primaryKey(),
  feedItemId: integer("feed_item_id").references(() => feedItems.id, { onDelete: "set null" }),
  templateId: integer("template_id").references(() => templates.id, { onDelete: "set null" }),
  platform: varchar("platform", { length: 16 }).notNull(),
  content: text("content").notNull(),
  // gemini | fallback
  generator: varchar("generator", { length: 32 }).notNull().default("fallback"),
  // draft | published | simulated | failed
  status: varchar("status", { length: 16 }).notNull().default("draft"),
  publishedId: text("published_id"),
  publishedUrl: text("published_url"),
  error: text("error"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  publishedAt: timestamp("published_at", { withTimezone: true }),
});

export const ingestRuns = pgTable("ingest_runs", {
  id: serial("id").primaryKey(),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
  finishedAt: timestamp("finished_at", { withTimezone: true }),
  sourcesChecked: integer("sources_checked").notNull().default(0),
  itemsFetched: integer("items_fetched").notNull().default(0),
  itemsInserted: integer("items_inserted").notNull().default(0),
  errors: jsonb("errors").$type<{ source: string; error: string }[]>().notNull().default([]),
});

export type Category = typeof categories.$inferSelect;
export type Source = typeof sources.$inferSelect;
export type FeedItem = typeof feedItems.$inferSelect;
export type Template = typeof templates.$inferSelect;
export type Draft = typeof drafts.$inferSelect;
export type IngestRun = typeof ingestRuns.$inferSelect;
