"use client";

import { useDraggable } from "@dnd-kit/core";
import { CSS } from "@dnd-kit/utilities";
import { hostname, timeAgo } from "@/lib/text";
import { CATEGORY_COLORS, SOURCE_TYPE_LABEL, SOURCE_TYPE_STYLE, type ClientCategory, type ClientFeedItem } from "./types";

type Props = {
  item: ClientFeedItem;
  category?: ClientCategory;
  onArchive?: (id: number) => void;
  onQuickDraft?: (item: ClientFeedItem, platform: "x" | "threads") => void;
  overlay?: boolean;
};

export function FeedCard({ item, category, onArchive, onQuickDraft, overlay }: Props) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: `item-${item.id}`,
    data: { item },
    disabled: overlay,
  });

  const colors = CATEGORY_COLORS[category?.color ?? "slate"] ?? CATEGORY_COLORS.slate;

  return (
    <article
      ref={setNodeRef}
      style={{ transform: CSS.Translate.toString(transform) }}
      className={[
        "group relative flex flex-col gap-2 rounded-xl border border-white/10 bg-slate-900/70 p-3.5 shadow-sm transition",
        overlay ? "w-[320px] rotate-1 scale-[1.03] border-emerald-400/50 shadow-2xl shadow-emerald-900/40" : "hover:border-white/20 hover:bg-slate-900",
        isDragging && !overlay ? "opacity-30" : "",
      ].join(" ")}
    >
      <div className="flex items-start gap-2">
        <button
          {...listeners}
          {...attributes}
          aria-label="Drag to a template"
          title="Drag onto X or Threads template →"
          className="mt-0.5 shrink-0 cursor-grab touch-none rounded-md p-1 text-slate-500 hover:bg-white/5 hover:text-slate-200 active:cursor-grabbing"
        >
          <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden>
            <circle cx="5" cy="3" r="1.4" /><circle cx="11" cy="3" r="1.4" />
            <circle cx="5" cy="8" r="1.4" /><circle cx="11" cy="8" r="1.4" />
            <circle cx="5" cy="13" r="1.4" /><circle cx="11" cy="13" r="1.4" />
          </svg>
        </button>
        <div className="min-w-0 flex-1">
          <div className="mb-1 flex flex-wrap items-center gap-1.5 text-[11px]">
            <span className={`rounded-full px-2 py-0.5 ring-1 ${colors.chip}`}>{category?.name ?? item.categorySlug}</span>
            <span className={`rounded-full px-2 py-0.5 ${SOURCE_TYPE_STYLE[item.sourceType] ?? ""}`}>{SOURCE_TYPE_LABEL[item.sourceType] ?? item.sourceType}</span>
            {item.isDeal && <span className="rounded-full bg-emerald-400 px-2 py-0.5 font-semibold text-emerald-950">DEAL</span>}
          </div>
          <a
            href={item.link}
            target="_blank"
            rel="noreferrer noopener"
            className="line-clamp-2 text-[15px] font-medium leading-snug text-slate-100 hover:text-emerald-300"
          >
            {item.title}
          </a>
          {item.snippet && <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-slate-400">{item.snippet}</p>}
        </div>
      </div>

      <div className="flex items-center justify-between gap-2 text-[11px] text-slate-500">
        <span className="truncate">
          <span className="text-slate-300">{item.sourceName}</span> · {hostname(item.link)} · {timeAgo(item.publishedAt ?? item.createdAt)}
        </span>
        {!overlay && (
          <span className="flex shrink-0 items-center gap-1 opacity-0 transition group-hover:opacity-100">
            <button
              onClick={() => onQuickDraft?.(item, "x")}
              className="rounded-md border border-white/10 px-1.5 py-0.5 text-slate-300 hover:border-white/30 hover:text-white"
              title="Draft for X"
            >
              𝕏
            </button>
            <button
              onClick={() => onQuickDraft?.(item, "threads")}
              className="rounded-md border border-white/10 px-1.5 py-0.5 text-slate-300 hover:border-white/30 hover:text-white"
              title="Draft for Threads"
            >
              @
            </button>
            <button
              onClick={() => onArchive?.(item.id)}
              className="rounded-md border border-white/10 px-1.5 py-0.5 text-slate-400 hover:border-rose-400/40 hover:text-rose-300"
              title="Archive (hide)"
            >
              ✕
            </button>
          </span>
        )}
      </div>
    </article>
  );
}
