"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  KeyboardSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragStartEvent,
} from "@dnd-kit/core";
import Link from "next/link";
import { FeedCard } from "./FeedCard";
import { TemplateDropzone, PlatformIcon } from "./TemplateDropzone";
import { DraftModal } from "./DraftModal";
import { timeAgo } from "@/lib/text";
import {
  CATEGORY_COLORS,
  SOURCE_TYPE_LABEL,
  type ClientCategory,
  type ClientDraft,
  type ClientFeedItem,
  type ClientTemplate,
  type IntegrationStatus,
} from "./types";

type IngestSummary = { sourcesChecked: number; itemsFetched: number; itemsInserted: number; errors: { source: string; error: string }[]; durationMs: number };

export function Dashboard() {
  const [categories, setCategories] = useState<ClientCategory[]>([]);
  const [templates, setTemplates] = useState<ClientTemplate[]>([]);
  const [items, setItems] = useState<ClientFeedItem[]>([]);
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [drafts, setDrafts] = useState<ClientDraft[]>([]);
  const [integrations, setIntegrations] = useState<IntegrationStatus | null>(null);

  const [category, setCategory] = useState("all");
  const [sourceType, setSourceType] = useState("all");
  const [dealsOnly, setDealsOnly] = useState(false);
  const [q, setQ] = useState("");
  const [debouncedQ, setDebouncedQ] = useState("");

  const [loadingFeed, setLoadingFeed] = useState(true);
  const [ingesting, setIngesting] = useState(false);
  const [lastIngest, setLastIngest] = useState<IngestSummary | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const [activeItem, setActiveItem] = useState<ClientFeedItem | null>(null);
  const [busyTemplate, setBusyTemplate] = useState<number | null>(null);
  const [modal, setModal] = useState<{ draft: ClientDraft; template: ClientTemplate | null; warning: string | null } | null>(null);

  const bootstrapped = useRef(false);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
    useSensor(KeyboardSensor),
  );

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    window.setTimeout(() => setToast(null), 4500);
  }, []);

  const loadFeed = useCallback(async () => {
    setLoadingFeed(true);
    const params = new URLSearchParams({ category, sourceType, dealsOnly: dealsOnly ? "1" : "0", limit: "120" });
    if (debouncedQ) params.set("q", debouncedQ);
    const res = await fetch(`/api/feed?${params}`, { cache: "no-store" });
    const json = await res.json();
    setItems(json.items ?? []);
    const c: Record<string, number> = {};
    for (const row of json.counts ?? []) c[row.slug] = row.count;
    setCounts(c);
    setLoadingFeed(false);
    return (json.items ?? []).length as number;
  }, [category, sourceType, dealsOnly, debouncedQ]);

  const loadDrafts = useCallback(async () => {
    const res = await fetch("/api/drafts", { cache: "no-store" });
    const json = await res.json();
    setDrafts(json.drafts ?? []);
  }, []);

  const runIngest = useCallback(async () => {
    setIngesting(true);
    try {
      const res = await fetch("/api/ingest", { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
      const json = (await res.json()) as IngestSummary;
      setLastIngest(json);
      showToast(`Fetched ${json.itemsFetched} items from ${json.sourcesChecked} sources · ${json.itemsInserted} new · ${json.errors.length} errors`);
      await loadFeed();
    } catch (e) {
      showToast(`Ingest failed: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setIngesting(false);
    }
  }, [loadFeed, showToast]);

  useEffect(() => {
    const t = setTimeout(() => setDebouncedQ(q.trim()), 300);
    return () => clearTimeout(t);
  }, [q]);

  useEffect(() => {
    (async () => {
      const [c, t, i] = await Promise.all([
        fetch("/api/categories").then((r) => r.json()),
        fetch("/api/templates").then((r) => r.json()),
        fetch("/api/integrations").then((r) => r.json()),
      ]);
      setCategories(c.categories ?? []);
      setTemplates(t.templates ?? []);
      setIntegrations(i);
      loadDrafts();
    })();
  }, [loadDrafts]);

  useEffect(() => {
    loadFeed().then((n) => {
      // First visit on an empty database: kick off an ingest automatically.
      if (!bootstrapped.current && n === 0 && category === "all" && !debouncedQ && !dealsOnly && sourceType === "all") {
        bootstrapped.current = true;
        runIngest();
      }
      bootstrapped.current = true;
    });
  }, [loadFeed]); // eslint-disable-line react-hooks/exhaustive-deps

  const catBySlug = useMemo(() => Object.fromEntries(categories.map((c) => [c.slug, c])), [categories]);
  const totalNew = useMemo(() => Object.values(counts).reduce((a, b) => a + b, 0), [counts]);

  async function createDraft(item: ClientFeedItem, template: ClientTemplate) {
    setBusyTemplate(template.id);
    try {
      const res = await fetch("/api/drafts", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ feedItemId: item.id, templateId: template.id }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Failed to generate");
      setDrafts((d) => [json.draft, ...d]);
      setModal({ draft: json.draft, template, warning: json.warning });
    } catch (e) {
      showToast(`Draft failed: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setBusyTemplate(null);
    }
  }

  function onDragStart(e: DragStartEvent) {
    const item = (e.active.data.current as { item?: ClientFeedItem } | undefined)?.item;
    setActiveItem(item ?? null);
  }

  function onDragEnd(e: DragEndEvent) {
    const item = (e.active.data.current as { item?: ClientFeedItem } | undefined)?.item;
    const template = (e.over?.data.current as { template?: ClientTemplate } | undefined)?.template;
    setActiveItem(null);
    if (item && template) createDraft(item, template);
  }

  async function archive(id: number) {
    setItems((list) => list.filter((i) => i.id !== id));
    await fetch(`/api/feed/${id}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ status: "archived" }) });
    loadFeed();
  }

  function quickDraft(item: ClientFeedItem, platform: "x" | "threads") {
    const tpl = templates.find((t) => t.platform === platform);
    if (tpl) createDraft(item, tpl);
  }

  function onDraftUpdated(d: ClientDraft) {
    setDrafts((list) => list.map((x) => (x.id === d.id ? { ...x, ...d } : x)));
    setModal((m) => (m && m.draft.id === d.id ? { ...m, draft: { ...m.draft, ...d } } : m));
    if (d.status === "published" || d.status === "simulated") {
      setItems((list) => list.filter((i) => i.id !== d.feedItemId));
    }
  }

  async function deleteDraft(id: number) {
    setDrafts((list) => list.filter((d) => d.id !== id));
    await fetch(`/api/drafts/${id}`, { method: "DELETE" });
  }

  const statusPill = (ok: boolean, label: string, sub?: string) => (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[11px] ring-1 ${ok ? "bg-emerald-500/10 text-emerald-200 ring-emerald-400/30" : "bg-slate-500/10 text-slate-300 ring-white/10"}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${ok ? "bg-emerald-400" : "bg-slate-500"}`} />
      {label}
      {sub && <span className="text-slate-400">· {sub}</span>}
    </span>
  );

  return (
    <DndContext sensors={sensors} onDragStart={onDragStart} onDragEnd={onDragEnd}>
      <main className="mx-auto grid max-w-[1600px] grid-cols-1 gap-5 px-4 py-5 lg:grid-cols-[220px_minmax(0,1fr)_340px]">
        {/* ---------------- Left: filters ---------------- */}
        <aside className="space-y-5 lg:sticky lg:top-[72px] lg:self-start">
          <div>
            <div className="mb-2 flex items-center justify-between text-[11px] uppercase tracking-wider text-slate-500">
              <span>Categories</span>
              <span>{totalNew}</span>
            </div>
            <ul className="space-y-0.5">
              <li>
                <button
                  onClick={() => setCategory("all")}
                  className={`flex w-full items-center justify-between rounded-lg px-2.5 py-1.5 text-sm ${category === "all" ? "bg-white/10 text-white" : "text-slate-300 hover:bg-white/5"}`}
                >
                  <span>All</span>
                  <span className="text-xs text-slate-500">{totalNew}</span>
                </button>
              </li>
              {categories.map((c) => {
                const col = CATEGORY_COLORS[c.color] ?? CATEGORY_COLORS.slate;
                return (
                  <li key={c.slug}>
                    <button
                      onClick={() => setCategory(c.slug)}
                      title={c.description ?? undefined}
                      className={`flex w-full items-center justify-between rounded-lg px-2.5 py-1.5 text-sm ${category === c.slug ? "bg-white/10 text-white" : "text-slate-300 hover:bg-white/5"}`}
                    >
                      <span className="flex items-center gap-2 truncate">
                        <span className={`h-2 w-2 shrink-0 rounded-full ${col.dot}`} />
                        <span className="truncate">{c.name}</span>
                      </span>
                      <span className="text-xs text-slate-500">{counts[c.slug] ?? 0}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>

          <div>
            <div className="mb-2 text-[11px] uppercase tracking-wider text-slate-500">Source type</div>
            <div className="flex flex-wrap gap-1.5">
              {["all", "official", "influencer", "community", "deals"].map((t) => (
                <button
                  key={t}
                  onClick={() => setSourceType(t)}
                  className={`rounded-full px-2.5 py-1 text-xs ring-1 ${sourceType === t ? "bg-white text-black ring-white" : "text-slate-300 ring-white/10 hover:bg-white/5"}`}
                >
                  {t === "all" ? "All" : SOURCE_TYPE_LABEL[t]}
                </button>
              ))}
            </div>
          </div>

          <label className="flex cursor-pointer items-center gap-2 text-sm text-slate-300">
            <input type="checkbox" checked={dealsOnly} onChange={(e) => setDealsOnly(e.target.checked)} className="h-4 w-4 accent-emerald-400" />
            Deal signals only
          </label>

          <div className="space-y-2 rounded-xl border border-white/10 bg-slate-900/50 p-3 text-xs">
            <div className="text-[11px] uppercase tracking-wider text-slate-500">Integrations</div>
            {integrations ? (
              <div className="flex flex-col gap-1.5">
                {statusPill(integrations.gemini.configured, "Gemini", integrations.gemini.configured ? integrations.gemini.model : "fallback")}
                {statusPill(integrations.x.configured, "X API", integrations.x.configured ? integrations.x.mode : "simulated")}
                {statusPill(integrations.threads.configured, "Threads API", integrations.threads.configured ? "live" : "simulated")}
              </div>
            ) : (
              <div className="text-slate-500">Checking…</div>
            )}
            <Link href="/settings" className="block pt-1 text-emerald-300 hover:underline">
              Configure →
            </Link>
          </div>
        </aside>

        {/* ---------------- Center: feed ---------------- */}
        <section className="min-w-0">
          <div className="mb-4 flex flex-wrap items-center gap-2">
            <div className="relative min-w-[220px] flex-1">
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search titles, snippets, sources…"
                className="w-full rounded-xl border border-white/10 bg-slate-900/70 py-2 pl-9 pr-3 text-sm outline-none placeholder:text-slate-500 focus:border-emerald-400/50"
              />
              <span className="pointer-events-none absolute left-3 top-2.5 text-slate-500">⌕</span>
            </div>
            <button
              onClick={runIngest}
              disabled={ingesting}
              className="inline-flex items-center gap-2 rounded-xl bg-emerald-400 px-4 py-2 text-sm font-semibold text-emerald-950 hover:bg-emerald-300 disabled:opacity-60"
            >
              {ingesting ? (
                <>
                  <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-emerald-900 border-t-transparent" />
                  Fetching sources…
                </>
              ) : (
                <>↻ Refresh feed</>
              )}
            </button>
          </div>

          {lastIngest && (
            <div className="mb-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-400">
              <span>
                Last run: <span className="text-slate-200">{lastIngest.sourcesChecked}</span> sources ·{" "}
                <span className="text-slate-200">{lastIngest.itemsFetched}</span> fetched ·{" "}
                <span className="text-emerald-300">{lastIngest.itemsInserted} new</span> · {(lastIngest.durationMs / 1000).toFixed(1)}s
              </span>
              {lastIngest.errors.length > 0 && (
                <details className="text-amber-300">
                  <summary className="cursor-pointer">{lastIngest.errors.length} source errors</summary>
                  <ul className="mt-1 space-y-0.5 text-amber-200/80">
                    {lastIngest.errors.map((e, i) => (
                      <li key={i}>
                        {e.source}: {e.error}
                      </li>
                    ))}
                  </ul>
                </details>
              )}
            </div>
          )}

          {loadingFeed && items.length === 0 ? (
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-2 2xl:grid-cols-3">
              {Array.from({ length: 9 }).map((_, i) => (
                <div key={i} className="h-36 animate-pulse rounded-xl border border-white/5 bg-slate-900/50" />
              ))}
            </div>
          ) : items.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-white/10 p-12 text-center text-sm text-slate-400">
              {ingesting ? "Fetching your sources for the first time…" : "Nothing here yet. Try another filter or hit Refresh feed."}
            </div>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2 2xl:grid-cols-3">
              {items.map((item) => (
                <FeedCard key={item.id} item={item} category={catBySlug[item.categorySlug]} onArchive={archive} onQuickDraft={quickDraft} />
              ))}
            </div>
          )}
        </section>

        {/* ---------------- Right: templates + drafts ---------------- */}
        <aside className="space-y-4 lg:sticky lg:top-[72px] lg:max-h-[calc(100vh-88px)] lg:self-start lg:overflow-y-auto lg:pr-1">
          <div>
            <div className="mb-2 flex items-center justify-between">
              <span className="text-[11px] uppercase tracking-wider text-slate-500">Post templates</span>
              <Link href="/settings" className="text-[11px] text-slate-400 hover:text-white">
                Edit
              </Link>
            </div>
            <div className="space-y-3">
              {templates.map((t) => (
                <TemplateDropzone
                  key={t.id}
                  template={t}
                  busy={busyTemplate === t.id}
                  disabledReason={
                    integrations && !integrations.gemini.configured
                      ? "No GEMINI_API_KEY — drafts use the template fallback"
                      : null
                  }
                />
              ))}
            </div>
            <p className="mt-2 text-[11px] leading-relaxed text-slate-500">
              Drop a card → Gemini rewrites it for that platform → review, edit, then post. Nothing is published without your click.
            </p>
          </div>

          <div>
            <div className="mb-2 flex items-center justify-between">
              <span className="text-[11px] uppercase tracking-wider text-slate-500">Recent drafts</span>
              <span className="text-[11px] text-slate-500">{drafts.length}</span>
            </div>
            {drafts.length === 0 ? (
              <div className="rounded-xl border border-white/5 bg-slate-900/40 p-4 text-center text-xs text-slate-500">No drafts yet.</div>
            ) : (
              <ul className="space-y-2">
                {drafts.slice(0, 25).map((d) => {
                  const tpl = templates.find((t) => t.id === d.templateId) ?? null;
                  const statusStyle =
                    d.status === "published"
                      ? "bg-emerald-400 text-emerald-950"
                      : d.status === "simulated"
                        ? "bg-sky-500/20 text-sky-200"
                        : d.status === "failed"
                          ? "bg-rose-500/20 text-rose-200"
                          : "bg-white/10 text-slate-200";
                  return (
                    <li key={d.id} className="group rounded-xl border border-white/10 bg-slate-900/60 p-3">
                      <div className="mb-1 flex items-center gap-2">
                        <span className={`flex h-5 w-5 items-center justify-center rounded ${d.platform === "x" ? "bg-black text-white ring-1 ring-white/20" : "bg-white text-black"}`}>
                          <PlatformIcon platform={d.platform} className="h-3 w-3" />
                        </span>
                        <span className={`rounded-full px-1.5 py-0.5 text-[10px] font-semibold uppercase ${statusStyle}`}>{d.status}</span>
                        <span className="ml-auto text-[10px] text-slate-500">{timeAgo(d.createdAt)}</span>
                      </div>
                      <button
                        onClick={() => setModal({ draft: d, template: tpl, warning: null })}
                        className="line-clamp-3 w-full text-left text-xs leading-relaxed text-slate-300 hover:text-white"
                      >
                        {d.content}
                      </button>
                      {d.error && <div className="mt-1 text-[10px] text-rose-300">{d.error}</div>}
                      <div className="mt-2 flex items-center gap-2 text-[10px]">
                        {d.publishedUrl && d.status === "published" && (
                          <a href={d.publishedUrl} target="_blank" rel="noreferrer" className="text-emerald-300 hover:underline">
                            View post
                          </a>
                        )}
                        <button onClick={() => setModal({ draft: d, template: tpl, warning: null })} className="text-slate-400 hover:text-white">
                          Open
                        </button>
                        <button onClick={() => deleteDraft(d.id)} className="ml-auto text-slate-500 hover:text-rose-300">
                          Delete
                        </button>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </aside>
      </main>

      <DragOverlay dropAnimation={null}>{activeItem ? <FeedCard item={activeItem} category={catBySlug[activeItem.categorySlug]} overlay /> : null}</DragOverlay>

      {modal && (
        <DraftModal
          key={modal.draft.id}
          draft={modal.draft}
          template={modal.template}
          warning={modal.warning}
          onClose={() => setModal(null)}
          onUpdated={onDraftUpdated}
        />
      )}

      {toast && (
        <div className="fixed bottom-5 left-1/2 z-50 -translate-x-1/2 rounded-xl border border-white/10 bg-slate-800 px-4 py-2 text-sm shadow-xl">{toast}</div>
      )}
    </DndContext>
  );
}
