"use client";

import { useEffect, useState } from "react";
import { HARD_LIMITS, effectiveLength } from "@/lib/text";
import type { ClientDraft, ClientTemplate } from "./types";
import { PlatformIcon } from "./TemplateDropzone";

type Props = {
  draft: ClientDraft;
  template?: ClientTemplate | null;
  warning?: string | null;
  onClose: () => void;
  onUpdated: (d: ClientDraft) => void;
};

export function DraftModal({ draft, template, warning, onClose, onUpdated }: Props) {
  const [content, setContent] = useState(draft.content);
  const [saving, setSaving] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [regenerating, setRegenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(warning ?? null);
  const [result, setResult] = useState<{ mode: string; url: string | null; note: string | null } | null>(null);

  useEffect(() => {
    setContent(draft.content);
  }, [draft.id, draft.content]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const platform = draft.platform;
  const hard = HARD_LIMITS[platform] ?? 280;
  const soft = template?.maxChars ?? hard;
  const len = effectiveLength(content, platform);
  const over = len > hard;
  const nearly = !over && len > soft;
  const isX = platform === "x";
  const done = draft.status === "published" || draft.status === "simulated" || Boolean(result);

  async function save() {
    setSaving(true);
    setError(null);
    try {
      const res = await fetch(`/api/drafts/${draft.id}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ content }) });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Save failed");
      onUpdated({ ...draft, ...json.draft });
      setNotice("Saved.");
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setSaving(false);
    }
  }

  async function regenerate() {
    setRegenerating(true);
    setError(null);
    try {
      const res = await fetch(`/api/drafts/${draft.id}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ regenerate: true }) });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Regenerate failed");
      setContent(json.draft.content);
      onUpdated({ ...draft, ...json.draft });
      setNotice(json.warning ?? `Regenerated with ${json.draft.generator}.`);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setRegenerating(false);
    }
  }

  async function publish() {
    if (over) return;
    setPublishing(true);
    setError(null);
    try {
      const res = await fetch(`/api/drafts/${draft.id}/publish`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ content }) });
      const json = await res.json();
      if (!res.ok) {
        if (json.draft) onUpdated({ ...draft, ...json.draft });
        throw new Error(json.error ?? "Publish failed");
      }
      onUpdated({ ...draft, ...json.draft });
      setResult({ mode: json.mode, url: json.draft.publishedUrl ?? null, note: json.note ?? null });
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setPublishing(false);
    }
  }

  async function copy() {
    try {
      await navigator.clipboard.writeText(content);
      setNotice("Copied to clipboard.");
    } catch {
      setError("Clipboard not available.");
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm" onClick={onClose}>
      <div
        className="w-full max-w-2xl overflow-hidden rounded-2xl border border-white/10 bg-slate-900 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal
      >
        <div className="flex items-center gap-3 border-b border-white/10 px-5 py-4">
          <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${isX ? "bg-black text-white ring-1 ring-white/20" : "bg-white text-black"}`}>
            <PlatformIcon platform={platform} className="h-4 w-4" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-sm font-semibold">
              {isX ? "X post preview" : "Threads post preview"}
              <span className="ml-2 rounded-full bg-white/10 px-2 py-0.5 text-[10px] font-normal uppercase tracking-wide text-slate-300">
                {draft.generator === "gemini" ? "Gemini" : "Template fallback"}
              </span>
            </div>
            {draft.itemTitle && <div className="truncate text-xs text-slate-400">From: {draft.itemTitle}</div>}
          </div>
          <button onClick={onClose} className="rounded-md p-1.5 text-slate-400 hover:bg-white/10 hover:text-white" aria-label="Close">
            ✕
          </button>
        </div>

        <div className="space-y-3 px-5 py-4">
          {notice && <div className="rounded-lg border border-amber-400/20 bg-amber-500/10 px-3 py-2 text-xs text-amber-100">{notice}</div>}
          {error && <div className="rounded-lg border border-rose-400/30 bg-rose-500/10 px-3 py-2 text-xs text-rose-200">{error}</div>}

          {result ? (
            <div className="rounded-xl border border-emerald-400/30 bg-emerald-500/10 p-4">
              <div className="text-sm font-semibold text-emerald-200">
                {result.mode === "live" ? "Published! 🎉" : "Simulated publish ✅"}
              </div>
              {result.note && <p className="mt-1 text-xs text-emerald-100/80">{result.note}</p>}
              {result.url && result.mode === "live" && (
                <a href={result.url} target="_blank" rel="noreferrer" className="mt-2 inline-block text-xs text-emerald-300 underline">
                  Open post →
                </a>
              )}
              <pre className="mt-3 whitespace-pre-wrap rounded-lg bg-black/30 p-3 font-sans text-sm text-slate-100">{content}</pre>
            </div>
          ) : (
            <>
              <div className={`rounded-xl border p-3 ${isX ? "border-white/10 bg-black" : "border-white/10 bg-slate-950"}`}>
                <div className="mb-2 flex items-center gap-2">
                  <div className="h-8 w-8 rounded-full bg-gradient-to-br from-emerald-400 to-sky-500" />
                  <div className="text-xs">
                    <div className="font-semibold">You</div>
                    <div className="text-slate-500">@yourhandle · now</div>
                  </div>
                </div>
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  rows={Math.min(14, Math.max(6, content.split("\n").length + 2))}
                  disabled={done}
                  className="w-full resize-y rounded-md bg-transparent font-sans text-[15px] leading-relaxed text-slate-100 outline-none placeholder:text-slate-600 focus:ring-1 focus:ring-emerald-400/40"
                  spellCheck
                />
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className={over ? "font-semibold text-rose-300" : nearly ? "text-amber-300" : "text-slate-400"}>
                  {len}/{hard} chars{isX ? " (links = 23)" : ""} {over ? "— too long" : nearly ? "— over template target" : ""}
                </span>
                <span className="text-slate-500">
                  {template ? `Template: ${template.name}` : ""}
                </span>
              </div>
              <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
                <div
                  className={`h-full transition-all ${over ? "bg-rose-400" : nearly ? "bg-amber-400" : "bg-emerald-400"}`}
                  style={{ width: `${Math.min(100, (len / hard) * 100)}%` }}
                />
              </div>
            </>
          )}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-white/10 bg-slate-900/60 px-5 py-3">
          <div className="flex items-center gap-2">
            {!done && (
              <button
                onClick={regenerate}
                disabled={regenerating}
                className="rounded-lg border border-white/10 px-3 py-1.5 text-xs text-slate-200 hover:bg-white/5 disabled:opacity-50"
              >
                {regenerating ? "Regenerating…" : "↻ Regenerate"}
              </button>
            )}
            <button onClick={copy} className="rounded-lg border border-white/10 px-3 py-1.5 text-xs text-slate-200 hover:bg-white/5">
              Copy
            </button>
          </div>
          <div className="flex items-center gap-2">
            {done ? (
              <button onClick={onClose} className="rounded-lg bg-white/10 px-4 py-1.5 text-xs font-semibold hover:bg-white/20">
                Done
              </button>
            ) : (
              <>
                <button onClick={save} disabled={saving} className="rounded-lg border border-white/10 px-3 py-1.5 text-xs text-slate-200 hover:bg-white/5 disabled:opacity-50">
                  {saving ? "Saving…" : "Save draft"}
                </button>
                <button
                  onClick={publish}
                  disabled={publishing || over || !content.trim()}
                  className={`rounded-lg px-4 py-1.5 text-xs font-semibold disabled:cursor-not-allowed disabled:opacity-40 ${
                    isX ? "bg-white text-black hover:bg-slate-200" : "bg-emerald-400 text-emerald-950 hover:bg-emerald-300"
                  }`}
                >
                  {publishing ? "Publishing…" : isX ? "Post to X" : "Post to Threads"}
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
