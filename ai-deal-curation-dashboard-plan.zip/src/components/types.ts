import type { Category, Draft, FeedItem, Template } from "@/db/schema";

export type ClientFeedItem = Omit<FeedItem, "publishedAt" | "createdAt"> & { publishedAt: string | null; createdAt: string };
export type ClientDraft = Omit<Draft, "createdAt" | "publishedAt"> & {
  createdAt: string;
  publishedAt: string | null;
  itemTitle?: string | null;
  itemLink?: string | null;
};
export type ClientTemplate = Omit<Template, "createdAt"> & { createdAt: string };
export type ClientCategory = Category;

export type IntegrationStatus = {
  gemini: { configured: boolean; model: string };
  x: { configured: boolean; mode: "oauth1" | "oauth2" | "none" };
  threads: { configured: boolean; userId: string };
  simulate: boolean;
};

export const CATEGORY_COLORS: Record<string, { chip: string; dot: string; ring: string }> = {
  emerald: { chip: "bg-emerald-500/15 text-emerald-300 ring-emerald-400/30", dot: "bg-emerald-400", ring: "ring-emerald-400/40" },
  sky: { chip: "bg-sky-500/15 text-sky-300 ring-sky-400/30", dot: "bg-sky-400", ring: "ring-sky-400/40" },
  violet: { chip: "bg-violet-500/15 text-violet-300 ring-violet-400/30", dot: "bg-violet-400", ring: "ring-violet-400/40" },
  amber: { chip: "bg-amber-500/15 text-amber-300 ring-amber-400/30", dot: "bg-amber-400", ring: "ring-amber-400/40" },
  rose: { chip: "bg-rose-500/15 text-rose-300 ring-rose-400/30", dot: "bg-rose-400", ring: "ring-rose-400/40" },
  fuchsia: { chip: "bg-fuchsia-500/15 text-fuchsia-300 ring-fuchsia-400/30", dot: "bg-fuchsia-400", ring: "ring-fuchsia-400/40" },
  slate: { chip: "bg-slate-500/15 text-slate-300 ring-slate-400/30", dot: "bg-slate-400", ring: "ring-slate-400/40" },
};

export const SOURCE_TYPE_LABEL: Record<string, string> = {
  official: "Official",
  influencer: "Creator",
  community: "Community",
  deals: "Deal tracker",
};

export const SOURCE_TYPE_STYLE: Record<string, string> = {
  official: "bg-blue-500/15 text-blue-200",
  influencer: "bg-pink-500/15 text-pink-200",
  community: "bg-orange-500/15 text-orange-200",
  deals: "bg-emerald-500/15 text-emerald-200",
};
