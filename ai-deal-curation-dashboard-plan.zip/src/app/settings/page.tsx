"use client";

import { useEffect, useState } from "react";
import type { ClientTemplate, IntegrationStatus } from "@/components/types";
import { PlatformIcon } from "@/components/TemplateDropzone";

export default function SettingsPage() {
  const [templates, setTemplates] = useState<ClientTemplate[]>([]);
  const [status, setStatus] = useState<IntegrationStatus | null>(null);
  const [saving, setSaving] = useState<number | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [refreshMsg, setRefreshMsg] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/templates").then((r) => r.json()).then((j) => setTemplates(j.templates ?? []));
    fetch("/api/integrations").then((r) => r.json()).then(setStatus);
  }, []);

  function update(id: number, patch: Partial<ClientTemplate>) {
    setTemplates((list) => list.map((t) => (t.id === id ? { ...t, ...patch } : t)));
  }

  async function save(t: ClientTemplate) {
    setSaving(t.id);
    setMsg(null);
    const res = await fetch("/api/templates", {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id: t.id, name: t.name, instructions: t.instructions, maxChars: t.maxChars, hashtags: t.hashtags, includeLink: t.includeLink, tone: t.tone }),
    });
    setSaving(null);
    setMsg(res.ok ? `Saved "${t.name}".` : "Save failed.");
  }

  async function refreshThreads() {
    setRefreshMsg("Refreshing…");
    const res = await fetch("/api/integrations", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "refresh-threads-token" }) });
    const j = await res.json();
    setRefreshMsg(j.ok ? `New token valid ~${j.expiresInDays} days: ${j.tokenPreview}. Update THREADS_ACCESS_TOKEN in your env.` : `Refresh failed: ${j.error}`);
  }

  const Row = ({ ok, name, children }: { ok: boolean; name: string; children: React.ReactNode }) => (
    <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-4">
      <div className="mb-2 flex items-center gap-2">
        <span className={`h-2.5 w-2.5 rounded-full ${ok ? "bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]" : "bg-slate-500"}`} />
        <h3 className="font-semibold">{name}</h3>
        <span className={`ml-auto rounded-full px-2 py-0.5 text-[11px] ${ok ? "bg-emerald-500/15 text-emerald-200" : "bg-white/10 text-slate-300"}`}>{ok ? "configured" : "not configured"}</span>
      </div>
      <div className="space-y-2 text-sm text-slate-300">{children}</div>
    </div>
  );

  const Code = ({ children }: { children: React.ReactNode }) => <code className="rounded bg-black/40 px-1.5 py-0.5 font-mono text-[12px] text-emerald-200">{children}</code>;

  return (
    <main className="mx-auto max-w-6xl space-y-10 px-4 py-6">
      <section>
        <h1 className="text-xl font-semibold">Post templates</h1>
        <p className="mb-4 text-sm text-slate-400">These instructions are sent to Gemini together with the dropped feed item. Tweak the voice, limits and hashtags to taste.</p>
        {msg && <div className="mb-3 text-xs text-emerald-300">{msg}</div>}
        <div className="grid gap-4 lg:grid-cols-2">
          {templates.map((t) => (
            <div key={t.id} className="space-y-3 rounded-2xl border border-white/10 bg-slate-900/60 p-4">
              <div className="flex items-center gap-2">
                <span className={`flex h-8 w-8 items-center justify-center rounded-lg ${t.platform === "x" ? "bg-black text-white ring-1 ring-white/20" : "bg-white text-black"}`}>
                  <PlatformIcon platform={t.platform} className="h-4 w-4" />
                </span>
                <input value={t.name} onChange={(e) => update(t.id, { name: e.target.value })} className="flex-1 rounded-lg border border-white/10 bg-slate-950 px-3 py-1.5 text-sm font-medium outline-none focus:border-emerald-400/50" />
              </div>
              <textarea
                value={t.instructions}
                onChange={(e) => update(t.id, { instructions: e.target.value })}
                rows={6}
                className="w-full rounded-lg border border-white/10 bg-slate-950 px-3 py-2 text-sm leading-relaxed outline-none focus:border-emerald-400/50"
              />
              <div className="grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
                <label className="space-y-1">
                  <span className="text-slate-500">Tone</span>
                  <input value={t.tone} onChange={(e) => update(t.id, { tone: e.target.value })} className="w-full rounded-lg border border-white/10 bg-slate-950 px-2 py-1.5" />
                </label>
                <label className="space-y-1">
                  <span className="text-slate-500">Target chars</span>
                  <input type="number" min={40} max={t.platform === "x" ? 280 : 500} value={t.maxChars} onChange={(e) => update(t.id, { maxChars: Number(e.target.value) })} className="w-full rounded-lg border border-white/10 bg-slate-950 px-2 py-1.5" />
                </label>
                <label className="space-y-1">
                  <span className="text-slate-500">Hashtags</span>
                  <input value={t.hashtags} onChange={(e) => update(t.id, { hashtags: e.target.value })} className="w-full rounded-lg border border-white/10 bg-slate-950 px-2 py-1.5" />
                </label>
                <label className="flex items-end gap-2 pb-1.5">
                  <input type="checkbox" checked={t.includeLink} onChange={(e) => update(t.id, { includeLink: e.target.checked })} className="h-4 w-4 accent-emerald-400" />
                  <span>Include link</span>
                </label>
              </div>
              <div className="flex justify-end">
                <button onClick={() => save(t)} disabled={saving === t.id} className="rounded-lg bg-emerald-400 px-4 py-1.5 text-xs font-semibold text-emerald-950 hover:bg-emerald-300 disabled:opacity-60">
                  {saving === t.id ? "Saving…" : "Save template"}
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-xl font-semibold">Integrations</h2>
        <p className="mb-4 text-sm text-slate-400">
          Credentials are read from server-side environment variables only — they never reach the browser. Until they&apos;re set, drafts use a template fallback and publishing is <em>simulated</em> so you can test the whole flow safely.
        </p>
        <div className="grid gap-4 lg:grid-cols-3">
          <Row ok={Boolean(status?.gemini.configured)} name="Google AI Studio (Gemini)">
            <p>Powers the per-platform rewrite when you drop a card.</p>
            <ol className="list-decimal space-y-1 pl-4 text-xs text-slate-400">
              <li>Go to aistudio.google.com → <b>Get API key</b> → Create key (free tier).</li>
              <li>
                Set <Code>GEMINI_API_KEY</Code>. Optional: <Code>GEMINI_MODEL</Code> (default <Code>{status?.gemini.model ?? "gemini-2.5-flash"}</Code>).
              </li>
              <li>Free-tier limits are per-minute and per-day; this app makes one call per drop, so you&apos;re far below them.</li>
            </ol>
          </Row>

          <Row ok={Boolean(status?.x.configured)} name="X API (api.x.com/2/tweets)">
            <p>
              Mode: <b>{status?.x.mode ?? "…"}</b>. Posts under your own handle via user-context auth.
            </p>
            <ol className="list-decimal space-y-1 pl-4 text-xs text-slate-400">
              <li>developer.x.com → create a Project + App → <b>User authentication settings</b>: Read and Write.</li>
              <li>
                Under <b>Keys and tokens</b> generate all four and set: <Code>X_API_KEY</Code>, <Code>X_API_SECRET</Code>, <Code>X_ACCESS_TOKEN</Code>, <Code>X_ACCESS_SECRET</Code> (OAuth 1.0a — simplest for a single personal account).
              </li>
              <li>
                Alternative: an OAuth 2.0 user token with <Code>tweet.write</Code> scope in <Code>X_OAUTH2_ACCESS_TOKEN</Code>. Optional <Code>X_HANDLE</Code> for nicer links.
              </li>
              <li>Add credits in the Developer Console — writes are billed per post (link-bearing posts cost more).</li>
            </ol>
          </Row>

          <Row ok={Boolean(status?.threads.configured)} name="Threads API (graph.threads.net)">
            <p>Two-step publish: create text container → publish. Free, capped at 250 posts / 24h.</p>
            <ol className="list-decimal space-y-1 pl-4 text-xs text-slate-400">
              <li>developers.facebook.com → create app → add <b>Threads API</b> use case → add yourself as a Threads Tester and accept the invite in Threads settings.</li>
              <li>
                Generate a user token with <Code>threads_basic</Code> + <Code>threads_content_publish</Code>, exchange it for a 60-day long-lived token, set <Code>THREADS_ACCESS_TOKEN</Code>. Optional <Code>THREADS_USER_ID</Code> (defaults to <Code>me</Code>).
              </li>
              <li>Refresh the long-lived token before day 60 (button below calls the refresh endpoint).</li>
            </ol>
            <button onClick={refreshThreads} disabled={!status?.threads.configured} className="rounded-lg border border-white/10 px-3 py-1.5 text-xs hover:bg-white/5 disabled:opacity-40">
              Refresh Threads token
            </button>
            {refreshMsg && <div className="text-xs text-slate-300">{refreshMsg}</div>}
          </Row>
        </div>

        <div className="mt-4 rounded-2xl border border-white/10 bg-slate-900/40 p-4 text-xs text-slate-400">
          <div className="mb-1 font-semibold text-slate-200">Safety switches &amp; automation</div>
          <ul className="list-disc space-y-1 pl-4">
            <li>
              <Code>PUBLISH_SIMULATE=1</Code> forces simulated publishing even with real keys — handy while tuning templates.
            </li>
            <li>
              Schedule ingestion with any cron hitting <Code>GET /api/ingest?run=1</Code> (protect with <Code>CRON_SECRET</Code> → send <Code>Authorization: Bearer …</Code>). Hourly is the sweet spot; Reddit sources rotate two per run automatically.
            </li>
            <li>Duplicates are impossible by design: every item has a unique external ID and every post goes through your review modal.</li>
          </ul>
        </div>
      </section>
    </main>
  );
}
