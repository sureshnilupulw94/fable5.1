import { db } from "@/db";
import { categories } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { asc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  const rows = await db.select().from(categories).orderBy(asc(categories.sortOrder));
  return Response.json({ categories: rows });
}
