import { db } from "@/db";
import { sources } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = (await req.json()) as Partial<{ enabled: boolean; name: string; sourceType: string; maxItemsPerRun: number }>;
  const patch: Partial<typeof sources.$inferInsert> = {};
  if (typeof body.enabled === "boolean") patch.enabled = body.enabled;
  if (body.name?.trim()) patch.name = body.name.trim();
  if (body.sourceType) patch.sourceType = body.sourceType;
  if (typeof body.maxItemsPerRun === "number") patch.maxItemsPerRun = Math.max(1, Math.min(50, body.maxItemsPerRun));
  const [row] = await db.update(sources).set(patch).where(eq(sources.id, Number(id))).returning();
  if (!row) return Response.json({ error: "Not found" }, { status: 404 });
  return Response.json(row);
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  await db.delete(sources).where(eq(sources.id, Number(id)));
  return Response.json({ ok: true });
}
