import { db } from "@/db";
import { sources } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { asc } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  const rows = await db.select().from(sources).orderBy(asc(sources.sourceType), asc(sources.name));
  return Response.json({ sources: rows });
}

export async function POST(req: NextRequest) {
  const body = (await req.json()) as { name?: string; url?: string; kind?: string; sourceType?: string; maxItemsPerRun?: number };
  if (!body.name?.trim() || !body.url?.trim()) return Response.json({ error: "name and url are required" }, { status: 400 });
  const kind = ["rss", "hn", "reddit"].includes(body.kind ?? "") ? body.kind! : "rss";
  const sourceType = ["official", "influencer", "community", "deals"].includes(body.sourceType ?? "") ? body.sourceType! : "official";
  try {
    const [row] = await db
      .insert(sources)
      .values({ name: body.name.trim(), url: body.url.trim(), kind, sourceType, maxItemsPerRun: Math.max(1, Math.min(50, body.maxItemsPerRun ?? 15)) })
      .returning();
    return Response.json(row, { status: 201 });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    const status = msg.includes("unique") || msg.includes("duplicate") ? 409 : 500;
    return Response.json({ error: status === 409 ? "That URL already exists" : msg }, { status });
  }
}
