import { db } from "@/db";
import { feedItems } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { and, desc, eq, ilike, or, sql, ne } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  await ensureSeeded();
  const sp = req.nextUrl.searchParams;
  const category = sp.get("category");
  const q = sp.get("q")?.trim();
  const dealsOnly = sp.get("dealsOnly") === "1";
  const sourceType = sp.get("sourceType");
  const status = sp.get("status") ?? "new";
  const limit = Math.min(200, Number(sp.get("limit") ?? 80));

  const conds = [];
  if (status === "all") conds.push(ne(feedItems.status, "archived"));
  else conds.push(eq(feedItems.status, status));
  if (category && category !== "all") conds.push(eq(feedItems.categorySlug, category));
  if (dealsOnly) conds.push(eq(feedItems.isDeal, true));
  if (sourceType && sourceType !== "all") conds.push(eq(feedItems.sourceType, sourceType));
  if (q) conds.push(or(ilike(feedItems.title, `%${q}%`), ilike(feedItems.snippet, `%${q}%`), ilike(feedItems.sourceName, `%${q}%`)));

  const items = await db
    .select()
    .from(feedItems)
    .where(and(...conds))
    .orderBy(desc(sql`coalesce(${feedItems.publishedAt}, ${feedItems.createdAt})`))
    .limit(limit);

  const counts = await db
    .select({ slug: feedItems.categorySlug, count: sql<number>`count(*)::int` })
    .from(feedItems)
    .where(eq(feedItems.status, "new"))
    .groupBy(feedItems.categorySlug);

  return Response.json({ items, counts });
}
