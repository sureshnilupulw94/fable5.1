import { db } from "@/db";
import { feedItems } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = (await req.json()) as { status?: string; categorySlug?: string };
  const patch: Partial<typeof feedItems.$inferInsert> = {};
  if (body.status && ["new", "used", "archived"].includes(body.status)) patch.status = body.status;
  if (body.categorySlug) patch.categorySlug = body.categorySlug;
  if (!Object.keys(patch).length) return Response.json({ error: "Nothing to update" }, { status: 400 });

  const [row] = await db.update(feedItems).set(patch).where(eq(feedItems.id, Number(id))).returning();
  if (!row) return Response.json({ error: "Not found" }, { status: 404 });
  return Response.json(row);
}
