import { reclassifyAll, runIngest } from "@/lib/ingest";
import { db } from "@/db";
import { ingestRuns } from "@/db/schema";
import { desc } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

/**
 * POST /api/ingest            -> fetch all enabled sources
 * POST /api/ingest {sourceIds:[..]} -> fetch a subset
 * GET  /api/ingest?run=1      -> cron-friendly trigger (optionally protected by CRON_SECRET)
 * GET  /api/ingest            -> recent run history
 */
export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as { sourceIds?: number[]; reclassify?: boolean };
  if (body.reclassify) {
    const r = await reclassifyAll();
    return Response.json(r);
  }
  const summary = await runIngest({ sourceIds: body.sourceIds });
  return Response.json(summary);
}

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  if (sp.get("run") === "1") {
    const secret = process.env.CRON_SECRET;
    if (secret) {
      const auth = req.headers.get("authorization");
      if (auth !== `Bearer ${secret}` && sp.get("secret") !== secret) {
        return Response.json({ error: "Unauthorized" }, { status: 401 });
      }
    }
    const summary = await runIngest();
    return Response.json(summary);
  }
  const runs = await db.select().from(ingestRuns).orderBy(desc(ingestRuns.startedAt)).limit(20);
  return Response.json({ runs });
}
