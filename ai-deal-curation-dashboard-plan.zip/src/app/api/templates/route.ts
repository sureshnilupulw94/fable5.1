import { db } from "@/db";
import { templates } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { asc, eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  const rows = await db.select().from(templates).orderBy(asc(templates.sortOrder), asc(templates.id));
  return Response.json({ templates: rows });
}

export async function PATCH(req: NextRequest) {
  const body = (await req.json()) as Partial<{
    id: number;
    name: string;
    instructions: string;
    maxChars: number;
    hashtags: string;
    includeLink: boolean;
    tone: string;
  }>;
  if (!body.id) return Response.json({ error: "id required" }, { status: 400 });
  const patch: Partial<typeof templates.$inferInsert> = {};
  if (body.name?.trim()) patch.name = body.name.trim();
  if (typeof body.instructions === "string") patch.instructions = body.instructions;
  if (typeof body.maxChars === "number") patch.maxChars = Math.max(40, Math.min(500, body.maxChars));
  if (typeof body.hashtags === "string") patch.hashtags = body.hashtags.trim();
  if (typeof body.includeLink === "boolean") patch.includeLink = body.includeLink;
  if (body.tone?.trim()) patch.tone = body.tone.trim();
  const [row] = await db.update(templates).set(patch).where(eq(templates.id, body.id)).returning();
  if (!row) return Response.json({ error: "Not found" }, { status: 404 });
  return Response.json(row);
}
