import { db } from "@/db";
import { drafts, feedItems, templates } from "@/db/schema";
import { generateDraft } from "@/lib/curate";
import { desc, eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function GET() {
  const rows = await db
    .select({
      draft: drafts,
      itemTitle: feedItems.title,
      itemLink: feedItems.link,
    })
    .from(drafts)
    .leftJoin(feedItems, eq(drafts.feedItemId, feedItems.id))
    .orderBy(desc(drafts.createdAt))
    .limit(50);
  return Response.json({ drafts: rows.map((r) => ({ ...r.draft, itemTitle: r.itemTitle, itemLink: r.itemLink })) });
}

/** POST /api/drafts { feedItemId, templateId } -> generates an AI-curated draft (the drag-and-drop action). */
export async function POST(req: NextRequest) {
  const body = (await req.json()) as { feedItemId?: number; templateId?: number };
  if (!body.feedItemId || !body.templateId) return Response.json({ error: "feedItemId and templateId required" }, { status: 400 });

  const [item] = await db.select().from(feedItems).where(eq(feedItems.id, body.feedItemId));
  const [tpl] = await db.select().from(templates).where(eq(templates.id, body.templateId));
  if (!item || !tpl) return Response.json({ error: "Item or template not found" }, { status: 404 });

  const gen = await generateDraft(item, tpl);
  const [row] = await db
    .insert(drafts)
    .values({ feedItemId: item.id, templateId: tpl.id, platform: tpl.platform, content: gen.content, generator: gen.generator, status: "draft" })
    .returning();

  return Response.json({ draft: { ...row, itemTitle: item.title, itemLink: item.link }, warning: gen.warning ?? null, template: tpl });
}
