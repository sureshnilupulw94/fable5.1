import { db } from "@/db";
import { drafts, feedItems } from "@/db/schema";
import { effectiveLength } from "@/lib/curate";
import { publishToThreads, publishToX } from "@/lib/publish";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const HARD_LIMITS: Record<string, number> = { x: 280, threads: 500 };

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = (await req.json().catch(() => ({}))) as { content?: string };

  const [draft] = await db.select().from(drafts).where(eq(drafts.id, Number(id)));
  if (!draft) return Response.json({ error: "Not found" }, { status: 404 });
  if (draft.status === "published") return Response.json({ error: "Already published" }, { status: 409 });

  const content = (typeof body.content === "string" && body.content.trim() ? body.content : draft.content).trim();
  const limit = HARD_LIMITS[draft.platform] ?? 280;
  if (effectiveLength(content, draft.platform) > limit) {
    return Response.json({ error: `Post exceeds the ${limit}-character limit for ${draft.platform}` }, { status: 400 });
  }

  const result = draft.platform === "x" ? await publishToX(content) : await publishToThreads(content);

  if (!result.ok) {
    const [row] = await db.update(drafts).set({ content, status: "failed", error: result.error }).where(eq(drafts.id, draft.id)).returning();
    return Response.json({ draft: row, error: result.error }, { status: 502 });
  }

  const [row] = await db
    .update(drafts)
    .set({
      content,
      status: result.mode === "live" ? "published" : "simulated",
      publishedId: result.id,
      publishedUrl: result.url,
      publishedAt: new Date(),
      error: null,
    })
    .where(eq(drafts.id, draft.id))
    .returning();

  if (draft.feedItemId) {
    await db.update(feedItems).set({ status: "used" }).where(eq(feedItems.id, draft.feedItemId));
  }

  return Response.json({ draft: row, mode: result.mode, note: result.mode === "simulated" ? result.note : null });
}
