import { db } from "@/db";
import { drafts, feedItems, templates } from "@/db/schema";
import { generateDraft } from "@/lib/curate";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = (await req.json()) as { content?: string; regenerate?: boolean };

  const [existing] = await db.select().from(drafts).where(eq(drafts.id, Number(id)));
  if (!existing) return Response.json({ error: "Not found" }, { status: 404 });
  if (existing.status === "published") return Response.json({ error: "Already published" }, { status: 409 });

  if (body.regenerate) {
    const [item] = existing.feedItemId ? await db.select().from(feedItems).where(eq(feedItems.id, existing.feedItemId)) : [];
    const [tpl] = existing.templateId ? await db.select().from(templates).where(eq(templates.id, existing.templateId)) : [];
    if (!item || !tpl) return Response.json({ error: "Source item or template missing" }, { status: 404 });
    const gen = await generateDraft(item, tpl);
    const [row] = await db.update(drafts).set({ content: gen.content, generator: gen.generator }).where(eq(drafts.id, existing.id)).returning();
    return Response.json({ draft: row, warning: gen.warning ?? null });
  }

  if (typeof body.content !== "string" || !body.content.trim()) return Response.json({ error: "content required" }, { status: 400 });
  const [row] = await db.update(drafts).set({ content: body.content }).where(eq(drafts.id, existing.id)).returning();
  return Response.json({ draft: row });
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  await db.delete(drafts).where(eq(drafts.id, Number(id)));
  return Response.json({ ok: true });
}
