import { integrationStatus, refreshThreadsToken } from "@/lib/publish";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  return Response.json(integrationStatus());
}

/** POST /api/integrations { action: "refresh-threads-token" } */
export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as { action?: string };
  if (body.action === "refresh-threads-token") {
    const r = await refreshThreadsToken();
    // Never echo full tokens back to the browser; show a masked preview only.
    return Response.json({
      ok: r.ok,
      error: r.error ?? null,
      expiresInDays: r.expiresIn ? Math.round(r.expiresIn / 86400) : null,
      tokenPreview: r.token ? `${r.token.slice(0, 6)}…${r.token.slice(-4)} (copy from server logs / env update needed)` : null,
    });
  }
  return Response.json({ error: "Unknown action" }, { status: 400 });
}
