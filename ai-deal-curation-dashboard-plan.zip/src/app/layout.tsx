import type { Metadata } from "next";
import type { ReactNode } from "react";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "AI Deal Radar — curate & cross-post AI deals",
  description: "Aggregates AI tool deals, credits and launches from official and creator sources; drag to X/Threads templates for AI-curated posts.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="h-full">
      <body className="min-h-full bg-slate-950 text-slate-100 antialiased">
        <header className="sticky top-0 z-40 border-b border-white/10 bg-slate-950/80 backdrop-blur">
          <div className="mx-auto flex h-14 max-w-[1600px] items-center gap-6 px-4">
            <Link href="/" className="flex items-center gap-2 font-semibold tracking-tight">
              <span className="relative flex h-6 w-6 items-center justify-center rounded-full bg-emerald-500/20 ring-1 ring-emerald-400/50">
                <span className="h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_12px_2px_rgba(52,211,153,0.7)]" />
                <span className="absolute inset-0 animate-ping rounded-full bg-emerald-400/20" />
              </span>
              AI Deal Radar
            </Link>
            <nav className="flex items-center gap-1 text-sm text-slate-300">
              <Link href="/" className="rounded-md px-3 py-1.5 hover:bg-white/5 hover:text-white">
                Dashboard
              </Link>
              <Link href="/sources" className="rounded-md px-3 py-1.5 hover:bg-white/5 hover:text-white">
                Sources
              </Link>
              <Link href="/settings" className="rounded-md px-3 py-1.5 hover:bg-white/5 hover:text-white">
                Templates &amp; Integrations
              </Link>
            </nav>
          </div>
        </header>
        {children}
      </body>
    </html>
  );
}
