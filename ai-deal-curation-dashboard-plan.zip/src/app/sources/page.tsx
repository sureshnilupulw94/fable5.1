"use client";

import { useCallback, useEffect, useState } from "react";
import type { Source } from "@/db/schema";
import { SOURCE_TYPE_LABEL, SOURCE_TYPE_STYLE } from "@/components/types";
import { timeAgo } from "@/lib/text";

type ClientSource = Omit<Source, "lastFetchedAt" | "createdAt"> & { lastFetchedAt: string | null; createdAt: string };

export default function SourcesPage() {
  const [sources, setSources] = useState<ClientSource[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<number | null>(null);
  const [form, setForm] = useState({ name: "", url: "", kind: "rss", sourceType: "official", maxItemsPerRun: 15 });
  const [msg, setMsg] = useState<string | null>(null);
  const [filter, setFilter] = useState("all");

  const load = useCallback(async () => {
    const res = await fetch("/api/sources", { cache: "no-store" });
    const json = await res.json();
    setSources(json.sources ?? []);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function toggle(s: ClientSource) {
    setSources((list) => list.map((x) => (x.id === s.id ? { ...x, enabled: !s.enabled } : x)));
    await fetch(`/api/sources/${s.id}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ enabled: !s.enabled }) });
  }

  async function remove(s: ClientSource) {
    if (!confirm(`Remove "${s.name}"?`)) return;
    setSources((list) => list.filter((x) => x.id !== s.id));
    await fetch(`/api/sources/${s.id}`, { method: "DELETE" });
  }

  async function testOne(s: ClientSource) {
    setBusyId(s.id);
    try {
      const res = await fetch("/api/ingest", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ sourceIds: [s.id] }) });
      const json = await res.json();
      setMsg(json.errors?.length ? `${s.name}: ${json.errors[0].error}` : `${s.name}: fetched ${json.itemsFetched}, ${json.itemsInserted} new`);
      await load();
    } finally {
      setBusyId(null);
    }
  }

  async function add(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    const res = await fetch("/api/sources", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(form) });
    const json = await res.json();
    if (!res.ok) {
      setMsg(json.error ?? "Failed to add");
      return;
    }
    setForm({ name: "", url: "", kind: "rss", sourceType: "official", maxItemsPerRun: 15 });
    setMsg(`Added ${json.name}. Testing…`);
    await load();
    await testOne(json);
  }

  const visible = sources.filter((s) => filter === "all" || s.sourceType === filter);
  const okCount = sources.filter((s) => s.lastStatus === "ok").length;
  const errCount = sources.filter((s) => s.lastStatus === "error").length;

  return (
    <main className="mx-auto max-w-6xl px-4 py-6">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold">Sources</h1>
          <p className="text-sm text-slate-400">
            {sources.length} sources · <span className="text-emerald-300">{okCount} healthy</span> · <span className="text-amber-300">{errCount} erroring</span>. Reddit sources rotate 2 per run to respect rate limits.
          </p>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {["all", "official", "influencer", "community", "deals"].map((t) => (
            <button key={t} onClick={() => setFilter(t)} className={`rounded-full px-2.5 py-1 text-xs ring-1 ${filter === t ? "bg-white text-black ring-white" : "text-slate-300 ring-white/10 hover:bg-white/5"}`}>
              {t === "all" ? "All" : SOURCE_TYPE_LABEL[t]}
            </button>
          ))}
        </div>
      </div>

      <form onSubmit={add} className="mb-6 grid gap-2 rounded-2xl border border-white/10 bg-slate-900/60 p-4 md:grid-cols-[1fr_2fr_auto_auto_auto_auto]">
        <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Name (e.g. Cursor changelog)" className="rounded-lg border border-white/10 bg-slate-950 px-3 py-2 text-sm outline-none focus:border-emerald-400/50" />
        <input
          required
          value={form.url}
          onChange={(e) => setForm({ ...form, url: e.target.value })}
          placeholder="Feed URL — RSS/Atom URL, or hn:<query> for Hacker News search"
          className="rounded-lg border border-white/10 bg-slate-950 px-3 py-2 text-sm outline-none focus:border-emerald-400/50"
        />
        <select value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })} className="rounded-lg border border-white/10 bg-slate-950 px-2 py-2 text-sm">
          <option value="rss">RSS / Atom</option>
          <option value="hn">Hacker News (hn:query)</option>
        </select>
        <select value={form.sourceType} onChange={(e) => setForm({ ...form, sourceType: e.target.value })} className="rounded-lg border border-white/10 bg-slate-950 px-2 py-2 text-sm">
          {Object.entries(SOURCE_TYPE_LABEL).map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </select>
        <input type="number" min={1} max={50} value={form.maxItemsPerRun} onChange={(e) => setForm({ ...form, maxItemsPerRun: Number(e.target.value) })} title="Max items per run" className="w-20 rounded-lg border border-white/10 bg-slate-950 px-2 py-2 text-sm" />
        <button className="rounded-lg bg-emerald-400 px-4 py-2 text-sm font-semibold text-emerald-950 hover:bg-emerald-300">Add & test</button>
        {msg && <div className="text-xs text-slate-300 md:col-span-6">{msg}</div>}
      </form>

      {loading ? (
        <div className="text-sm text-slate-400">Loading…</div>
      ) : (
        <div className="overflow-hidden rounded-2xl border border-white/10">
          <table className="w-full text-sm">
            <thead className="bg-slate-900 text-left text-[11px] uppercase tracking-wider text-slate-500">
              <tr>
                <th className="px-3 py-2">On</th>
                <th className="px-3 py-2">Source</th>
                <th className="px-3 py-2">Type</th>
                <th className="px-3 py-2">Kind</th>
                <th className="px-3 py-2">Max/run</th>
                <th className="px-3 py-2">Last fetch</th>
                <th className="px-3 py-2">Status</th>
                <th className="px-3 py-2"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {visible.map((s) => (
                <tr key={s.id} className={`bg-slate-950/40 hover:bg-slate-900/60 ${!s.enabled ? "opacity-50" : ""}`}>
                  <td className="px-3 py-2">
                    <input type="checkbox" checked={s.enabled} onChange={() => toggle(s)} className="h-4 w-4 accent-emerald-400" />
                  </td>
                  <td className="max-w-[360px] px-3 py-2">
                    <div className="font-medium">{s.name}</div>
                    <div className="truncate text-[11px] text-slate-500" title={s.url}>
                      {s.url}
                    </div>
                  </td>
                  <td className="px-3 py-2">
                    <span className={`rounded-full px-2 py-0.5 text-[11px] ${SOURCE_TYPE_STYLE[s.sourceType] ?? ""}`}>{SOURCE_TYPE_LABEL[s.sourceType] ?? s.sourceType}</span>
                  </td>
                  <td className="px-3 py-2 text-xs text-slate-400">{s.kind}</td>
                  <td className="px-3 py-2 text-xs text-slate-400">{s.maxItemsPerRun}</td>
                  <td className="px-3 py-2 text-xs text-slate-400">{s.lastFetchedAt ? timeAgo(s.lastFetchedAt) : "never"}</td>
                  <td className="px-3 py-2">
                    {s.lastStatus === "ok" ? (
                      <span className="text-xs text-emerald-300">ok</span>
                    ) : s.lastStatus === "error" ? (
                      <span className="text-xs text-amber-300" title={s.lastError ?? ""}>
                        {(s.lastError ?? "error").slice(0, 40)}
                      </span>
                    ) : (
                      <span className="text-xs text-slate-500">—</span>
                    )}
                  </td>
                  <td className="whitespace-nowrap px-3 py-2 text-right text-xs">
                    <button onClick={() => testOne(s)} disabled={busyId === s.id} className="rounded-md border border-white/10 px-2 py-1 text-slate-300 hover:bg-white/5 disabled:opacity-50">
                      {busyId === s.id ? "Testing…" : "Test"}
                    </button>
                    <button onClick={() => remove(s)} className="ml-1 rounded-md border border-white/10 px-2 py-1 text-slate-400 hover:border-rose-400/40 hover:text-rose-300">
                      Remove
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </main>
  );
}
